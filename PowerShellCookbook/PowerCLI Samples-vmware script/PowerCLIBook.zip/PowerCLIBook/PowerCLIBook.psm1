#requires -version 2.0

[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo") | Out-Null

Function New-RegKey ($RegLocation, $RegKey, $RegValue) 
{
   If (Test-Path $RegLocation) 
   { 
   } 
   Else 
   { 
      Write "Creating Registry Key $RegLocation"
      Mkdir $RegLocation | Out-Null
   }
   If (Get-ItemProperty $RegLocation $RegKey -ErrorAction SilentlyContinue) {
       Write "Registry Key '$RegKey' already Exists."
   } Else {
       Write "Creating $RegKey with a value of $RegValue"
       New-ItemProperty -Path $RegLocation -Name $RegKey -Value $RegValue `
       | Out-Null
   } 
}

function Import-Folders{ 
<#
.SYNOPSIS
  Imports a csv file of folders into vCenter Server and
  creates them automatically.
.DESCRIPTION
  The function will import folders from CSV file and create
  them in vCenter Server.
.NOTES
  Source:  Automating vSphere Administration
  Authors: Luc Dekens, Arnim van Lieshout, Jonathan Medd,
           Alan Renouf, Glenn Sizemore
.PARAMETER FolderType
  The type of folder to create
.PARAMETER DC
  The Datacenter to create the folder structure
.PARAMETER Filename
  The path of the CSV file to use when importing
.EXAMPLE 1
  PS> Import-Folders -FolderType "Blue" -DC "DC01" -Filename "C:\BlueFolders.csv"
.EXAMPLE 2
  PS> Import-Folders -FolderType "Yellow" -DC "Datacenter" -Filename "C:\YellowFolders.csv"
#>

  param( 
  [String]$FolderType, 
  [String]$DC,
  [String]$Filename
  ) 

  process{ 
    $vmfolder = Import-Csv $filename | Sort-Object -Property Path 
   If ($FolderType -eq "Yellow") {
      $type = "host"
   } Else {
      $type = "vm"
   }
   foreach($folder in $VMfolder){ 
      $key = @()
      $key =  ($folder.Path -split "\\")[-2] 
      if ($key -eq "vm") { 
         get-datacenter $dc | get-folder $type | New-Folder -Name $folder.Name 
      } else { 
        Get-Datacenter $dc | get-folder $type | get-folder $key | `
            New-Folder -Name $folder.Name  
      } 
   }
  } 
} 

Filter Get-FolderPath {
<#
.SYNOPSIS
  Colates the full folder path
.DESCRIPTION
  The function will find the full folder path returning a
  name and path
.NOTES
  Source:  Automating vSphere Administration
  Authors: Luc Dekens, Arnim van Lieshout, Jonathan Medd,
           Alan Renouf, Glenn Sizemore
#>
    $_ | Get-View | % {
        $row = "" | select Name, Path
        $row.Name = $_.Name

        $current = Get-View $_.Parent
        $path = $_.Name
        do {
            $parent = $current
            if($parent.Name -ne "vm"){$path = $parent.Name + "\" + $path}
            $current = Get-View $current.Parent
        } while ($current.Parent -ne $null)
        $row.Path = $path
        $row
    }
}

Function Export-Folders {
  <#
.SYNOPSIS
  Creates a csv file of folders in vCenter Server.
.DESCRIPTION
  The function will export folders from vCenter Server 
  and add them to a CSV file.
.NOTES
  Source:  Automating vSphere Administration
  Authors: Luc Dekens, Arnim van Lieshout, Jonathan Medd,
           Alan Renouf, Glenn Sizemore
.PARAMETER FolderType
  The type of folder to export
.PARAMETER DC
  The Datacenter where the folders reside
.PARAMETER Filename
  The path of the CSV file to use when exporting
.EXAMPLE 1
  PS> Export-Folders -FolderType "Blue" -DC "DC01" -Filename "C:\BlueFolders.csv"
.EXAMPLE 2
  PS> Export-Folders -FolderType "Yellow" -DC "Datacenter" 
  -Filename "C:\YellowFolders.csv"
#>

  param( 
  [String]$FolderType, 
  [String]$DC,
  [String]$Filename
  ) 
   
  Process {
   If ($Foldertype -eq "Yellow") {
      $type = "host"
   } Else {
     $type = "vm"
   }
   $report = @()
   $report = get-datacenter $dc | Get-folder $type | get-folder | Get-Folderpath
   $Report | foreach {
    if ($type -eq "vm") {
     $_.Path = ($_.Path).Replace($dc + "\","$type\")
    } 
   }
   $report | Export-Csv $filename -NoTypeInformation
  }
}

Function Export-VMLocation {
  <#
.SYNOPSIS
  Creates a csv file with the folder location of each VM.
.DESCRIPTION
  The function will export VM locations from vCenter Server 
  and add them to a CSV file.
.NOTES
  Source:  Automating vSphere Administration
  Authors: Luc Dekens, Arnim van Lieshout, Jonathan Medd,
           Alan Renouf, Glenn Sizemore
.PARAMETER DC
  The Datacenter where the folders reside
.PARAMETER Filename
  The path of the CSV file to use when exporting
.EXAMPLE 1
  PS> Export-VMLocation -DC "DC01" -Filename "C:\VMLocations.csv"
#>

  param( 
  [String]$DC,
  [String]$Filename
  )
  
  Process {
   $report = @()
   $report = get-datacenter $dc | get-vm | Get-Folderpath
   $report | Export-Csv $filename -NoTypeInformation
  }
}

Function Import-VMLocation {
 <#
.SYNOPSIS
  Imports the VMs back into their Blue Folders based on
  the data from a csv file.
.DESCRIPTION
  The function will import VM locations from CSV File 
  and add them to their correct Blue Folders.
.NOTES
  Source:  Automating vSphere Administration
  Authors: Luc Dekens, Arnim van Lieshout, Jonathan Medd,
           Alan Renouf, Glenn Sizemore
.PARAMETER DC
  The Datacenter where the folders reside
.PARAMETER Filename
  The path of the CSV file to use when importing
.EXAMPLE 1
  PS> Import-VMLocation -DC "DC01" -Filename "C:\VMLocations.csv"
#>

  param( 
  [String]$DC,
  [String]$Filename
  )
  
  Process {
   $Report = @()
   $Report = import-csv $filename | Sort-Object -Property Path
   foreach($vmpath in $Report){
      $key = @()
      $key =  Split-Path $vmpath.Path | split-path -leaf
      Move-VM (get-datacenter $dc `
      | Get-VM $vmpath.Name) -Destination (get-datacenter $dc | Get-folder $key) 
   }
  }
}

Function Export-PermissionsToCSV {
 <#
.SYNOPSIS
  Exports all Permissions to CSV file
.DESCRIPTION
  The function will export all permissions to a CSV
  based file for later import
.NOTES
  Source:  Automating vSphere Administration
  Authors: Luc Dekens, Arnim van Lieshout, Jonathan Medd,
           Alan Renouf, Glenn Sizemore
.PARAMETER Filename
  The path of the CSV file to be created
.EXAMPLE 1
  PS> Export-PermissionsToCSV -Filename "C:\Temp\Permissions.csv"
#>


  param( 
  [String]$Filename
  )
  
  Process {
   $folderperms = get-datacenter | Get-Folder | Get-VIPermission
   $vmperms = Get-Datacenter | get-vm | Get-VIPermission


   $permissions = get-datacenter | Get-VIpermission


   $report = @()
      foreach($perm in $permissions){
        $row = "" | select EntityId, Name, Role, Principal, IsGroup, Propagate
        $row.EntityId = $perm.EntityId
        $Foldername = (Get-View -id $perm.EntityId).Name
        $row.Name = $foldername
        $row.Principal = $perm.Principal
        $row.Role = $perm.Role
        $row.IsGroup = $perm.IsGroup
        $row.Propagate = $perm.Propagate
        $report += $row
    }


    foreach($perm in $folderperms){
        $row = "" | select EntityId, Name, Role, Principal, IsGroup, Propagate
        $row.EntityId = $perm.EntityId
        $Foldername = (Get-View -id $perm.EntityId).Name
        $row.Name = $foldername
        $row.Principal = $perm.Principal
        $row.Role = $perm.Role
        $row.IsGroup = $perm.IsGroup
        $row.Propagate = $perm.Propagate
        $report += $row
    }


    foreach($perm in $vmperms){
        $row = "" | select EntityId, Name, Role, Principal, IsGroup, Propagate
        $row.EntityId = $perm.EntityId
        $Foldername = (Get-View -id $perm.EntityId).Name
        $row.Name = $foldername
        $row.Principal = $perm.Principal
        $row.Role = $perm.Role
        $row.IsGroup = $perm.IsGroup
        $row.Propagate = $perm.Propagate
        $report += $row
    }


    $report | export-csv $Filename -NoTypeInformation
  }
}

function Import-Permissions {
<#
.SYNOPSIS
  Imports all Permissions from CSV file
.DESCRIPTION
  The function will import all permissions from a CSV
  file and apply them to the vCenter objects.
.NOTES
  Source:  Automating vSphere Administration
  Authors: Luc Dekens, Arnim van Lieshout, Jonathan Medd,
           Alan Renouf, Glenn Sizemore
.PARAMETER DC
  The Datacenter to import the permissions into
.PARAMETER Filename
  The path of the CSV file to be imported
.EXAMPLE 1
  PS> Import-Permissions -DC "DC01" -Filename "C:\Temp\Permissions.csv"
#>


param(
[String]$DC,
[String]$Filename
)


process {
 $permissions = @()
 $permissions = Import-Csv $Filename
 foreach ($perm in $permissions) {
  $entity = ""
  $entity = New-Object VMware.Vim.ManagedObjectReference
  $object = Get-Inventory -Name $perm.Name
  if($object.Count){
   $object = $object | where {$_.Id -eq $perm.EntityId}
  }
  if($object){
   switch -wildcard ($perm.EntityId)
   {
    Folder* {
     $entity.type = "Folder"
     $entity.value = $object.Id.Trimstart("Folder-")
    }
    VirtualMachine* {
     $entity.Type = "VirtualMachine"
     $entity.value = $object.Id.Trimstart("VirtualMachine-")
    }
    ClusterComputeResource* {
     $entity.Type = "ClusterComputeResource"
     $entity.value = $object.Id.Trimstart("ClusterComputeResource-")
    }
    Datacenter* {
	$entity.Type = "Datacenter"
     $entity.value = $object.Id.Trimstart("Datacenter-")
    }
   }
   $setperm = New-Object VMware.Vim.Permission
   $setperm.principal = $perm.Principal
   if ($perm.isgroup -eq "True") {
    $setperm.group = $true
   } else {
    $setperm.group = $false
   }
   $setperm.roleId = (Get-virole $perm.Role).id
   if ($perm.propagate -eq "True") {
    $setperm.propagate = $true
   } else {
    $setperm.propagate = $false
   }
   $doactual = Get-View -Id 'AuthorizationManager-AuthorizationManager'
   Write-Host "Setting Permissions on $($perm.Name) for $($perm.principal)"
   $doactual.SetEntityPermissions($entity, $setperm)
  }
 }
 }
}


Function Set-DPM {
 <#
.SYNOPSIS
  Enables Distributed Power Management on a cluster
.DESCRIPTION
  This funtion will allow you to configure
  DPM on an existing vCenter Server cluster
.NOTES
  Source:  Automating vSphere Administration
  Authors: Luc Dekens, Arnim van Lieshout, Jonathan Medd,
           Alan Renouf, Glenn Sizemore
.PARAMETER Cluster
  The cluster on which to set DPM configuration
.PARAMETER Behavior
  DPM Behavior, this can be set to "off", "manual" 
  or "Automated", by default it is "off"
.EXAMPLE 1
  PS> Set-DPM -Cluster "Cluster01" -Behavior "Automated"
#>

param( 
  [String]$Cluster,
  [String]$Behavior
  )
  
  Process {
   switch ($Behavior) {
            "Off" { 
               $DPMBehavior = "Automated" 
               $Enabled = $false
            }
            "Automated" { 
               $DPMBehavior = "Automated" 
               $Enabled = $true
            }
            "Manual" { 
               $DPMBehavior = "Manual" 
               $Enabled = $true
            }
            default {
               $DPMBehavior = "Automated" 
               $Enabled = $false
            }
      }
   $clus = Get-Cluster $Cluster | Get-View
   $spec = New-Object vmware.Vim.ClusterConfigSpecEx
   $spec.dpmConfig = New-Object VMware.Vim.ClusterDpmConfigInfo
   $spec.DpmConfig.DefaultDpmBehavior = $DPMBehavior
   $spec.DpmConfig.Enabled = $Enabled
   $clus.ReconfigureComputeResource_Task($spec, $true)
  }
}

Function Get-LicenseKey {
 <#
.SYNOPSIS
  Retrieves License Key information
.DESCRIPTION
  This funtion will list all licence keys added to 
  vCenter Server
.NOTES
  Source:  Automating vSphere Administration
  Authors: Luc Dekens, Arnim van Lieshout, Jonathan Medd,
           Alan Renouf, Glenn Sizemore
.EXAMPLE 1
  PS> Get-LicenseKey
#>
 
  Process {
   $servInst = Get-View ServiceInstance
   $licMgr = Get-View (Get-View ServiceInstance).Content.licenseManager
   $licMgr.Licenses
  }
}

Function Set-LicenseKey {
 <#
.SYNOPSIS
  Sets a License Key for a host
.DESCRIPTION
  This funtion will set a license key for a host
  which is attached to a vCenter server
.NOTES
  Source:  Automating vSphere Administration
  Authors: Luc Dekens, Arnim van Lieshout, Jonathan Medd,
           Alan Renouf, Glenn Sizemore
.PARAMETER LicKey
  The License Key
.PARAMETER VMHost
  The vSphere host which to set the license on
.PARAMETER Name
  The friendly name to give the license key
.EXAMPLE 1
  PS> Set-LicenseKey -LicKey "AAAAA-BBBBB-CCCCC-DDDDD-EEEEE" `
	-VMHost "esxhost01.mydomain.com" `
	-Name $null
#>

param( 
  [String]$VMHost, 
  [String]$LicKey, 
  [String]$Name
  )
  
  Process {
   $vmhostId = (Get-VMHost $VMHost | Get-View).Config.Host.Value
   $servInst = Get-View ServiceInstance
   $licMgr = Get-View $servInst.Content.licenseManager
   $licAssignMgr = Get-View $licMgr.licenseAssignmentManager

   $license = New-Object VMware.Vim.LicenseManagerLicenseInfo
   $license.LicenseKey = $LicKey
   $licAssignMgr.UpdateAssignedLicense($VMHostId, $license.LicenseKey, $Name)
   }
}

Function Wait-VMGuest
{
    <#
    .SYNOPSIS
        Wait while the VM performs a power operation.
    .DESCRIPTION
        Wait while the VM performs a power operation.  usefull when working with 
        VMGuests.  uses VMware tools to denote a startup, and powerOff.
    .NOTES
      Source:  Automating vSphere Administration
      Authors: Luc Dekens, Arnim van Lieshout, Jonathan Medd,
               Alan Renouf, Glenn Sizemore+
    .PARAMETER VM
        VM object to wait on
    .PARAMETER VMGuest
        VMGuest object to wait on
    .PARAMETER Operation
        Type of power Operation to wait on valid values are: 'Startup', and 'Shutdown'
    .EXAMPLE
        Get-VM VM01 | Start-VM | Wait-VM -Operation 'Startup'| Update-Tools
    .EXAMPLE
        Get-VM VM01 | Shutdown-VMGuest | Wait-VM -Operation 'Shutdown'| Set-vm -NumCpu 2 | start-VM
    #>
    [cmdletbinding(DefaultParameterSetName='VM')]
    Param(
        [parameter(Position=0
        ,    ParameterSetName='VM'
        )]
        [parameter(Position=0
        ,    ParameterSetName='Guest'
        )]
        [ValidateSet("Startup","Shutdown")]
        [string]
        $Operation
    ,
        [parameter(Mandatory=$True
        ,    ValueFromPipeline=$True
        ,    HelpMessage='Virtual Machine object to wait on'
        ,    ParameterSetName='VM'
        )]
        [VMware.VimAutomation.ViCore.Impl.V1.Inventory.VirtualMachineImpl]
        $VM
    ,   
        [parameter(Mandatory=$True
        ,    ValueFromPipeline=$True
        ,    HelpMessage='The VM Guest object to wait on'
        ,    ParameterSetName='Guest'
        )]
        [VMware.VimAutomation.ViCore.Impl.V1.VM.Guest.VMGuestImpl]
        $VMGuest
        
    )
    Process {
        IF ($PSCmdlet.ParameterSetName -eq 'Guest') {
            $VM = $VMGuest.VM
        }
        Switch ($Operation)
        {
            "Startup"
            {
                while ($vm.ExtensionData.Guest.ToolsRunningStatus -eq "guestToolsNotRunning")
                {
                    Start-Sleep -Seconds 1
                    $vm.ExtensionData.UpdateViewData("Guest")
                }
                # return a fresh VMObject
                Write-Output (Get-VM $VM)
                break;
            }
            "Shutdown"
            {
                # wait for the VM to be shutdown
                while ($VM.ExtensionData.Runtime.PowerState -ne "poweredOff")
                {
                    Start-Sleep -Seconds 1
                    $vm.ExtensionData.UpdateViewData("Runtime.PowerState")
                }
                # return a fresh VMObject
                Write-Output (Get-VM $VM)
                break;
            }
        }
    }
}

Function Update-TemplateHardware
{
    <#
    .SYNOPSIS
        Update Template to latest hardware version
    .DESCRIPTION
        Update Template to latest hardware version.  Requires the Update-Tools
        cmdlet so any template not supported will not work.
    .NOTES
        Source:  Automating vSphere Administration
        Authors: Luc Dekens, Arnim van Lieshout, Jonathan Medd,
               Alan Renouf, Glenn Sizemore
    .PARAMETER Template
        Template to Update
    .PARAMETER Version
        Desired Hardware version default vmx-07
    .EXAMPLE
        Update-TemplateHardware -Template (Get-Template WINXP_Template)
    .EXAMPLE
        Get-Template | Update-TemplateHardware
    #>

    [CmdletBinding()]
    param(
        [parameter(Mandatory=$True
        ,    ValueFromPipeline=$True
        ,    HelpMessage='Template object to upgrade'
        )]
        [VMware.VimAutomation.ViCore.Impl.V1.Inventory.TemplateImpl]
        $Template
    ,
        [parameter()]
        [ValidatePattern("vmx-\d\d")]
        [string]
        $Version="vmx-07"
    )
    Process
    {
        # Convert our template back to a virtual machine, and power it on.
        $VM = Set-Template -Template $Template -ToVM 
        
         #check VM Hardware version
        IF ($vm.ExtensionData.Config.Version -ne $Version)
        {
            write-host "VM Hardware version out of date!" -ForegroundColor 'RED'
            $VM = Start-VM -VM $VM | Wait-VMGuest Startup

            # Check VMware tools version if tools are out of date upgrade them.
            If ($vm.ExtensionData.Guest.ToolsStatus -ne "ToolsOk")
            {
                Write-Host 'VMware tools are out of date!' -ForegroundColor 'RED'
                #Kick off a tools update
                Try
                {
                    Update-Tools -VM $VM
                }
                Catch
                {
                    Write-Warning $_.exception.message
                    break;
                }
                Write-Host "Updating Tools..." -NoNewline
                #Wait for the update to finish
                while ($vm.ExtensionData.Guest.ToolsStatus -ne "ToolsOk")
                {
                    Start-Sleep -Seconds 1
                    Write-Host "." -NoNewline
                    $vm.ExtensionData.UpdateViewData("Guest")
                }
                write-host "DONE" -ForegroundColor 'Green'
                Write-Host "Tools upgrade complete, Starting hardware Upgrade"
            }
            Else
            {
                Write-Host "ToolsOK Starting hardware Upgrade" `
                    -ForegroundColor 'Green'
            }
     
            # Shut the VM back down
            Write-Host "Shut down guest"
            $VM = Shutdown-VMGuest -VM $VM -Confirm:$false | Wait-VMGuest Shutdown              
            $vm.ExtensionData.UpgradeVM("vmx-07")
            Write-Host "VM Hardware updated... Starting VM please log in and verify"
            $VM = Start-VM -VM $VM
        }
        Else
        {
            write-host "VM Hardware is up to date." -ForegroundColor 'Green'
            $VM = Set-VM -VM $VM -ToTemplate -Confirm:$false
        }
    }
}

function Set-VMOffline {
<#
.SYNOPSIS
  Changes the vCPU and memory configuration of the
  virtual machine Offline
.DESCRIPTION
  This function changes the vCPU and memory configuration of
  the virtual machine Offline
.NOTES
  Source:  Automating vSphere Administration
  Authors: Luc Dekens, Arnim van Lieshout, Jonathan Medd,
           Alan Renouf, Glenn Sizemore
.PARAMETER VM
  Specify the virtual machine
.PARAMETER MemoryMB
  Specify the memory size in MB
.PARAMETER NumCpu
  Specify the number of virtual CPUs
.PARAMETER TimeOut
  Specify the number of seconds to wait for the vm to shut down
  gracefully. Default timeout is 300 seconds
.PARAMETER Force
  Switch parameter to forcibly shutdown the virtual machine
  after timeout
.EXAMPLE
  PS> Get-VM VM001 | Set-VMOffline -memoryMB 4096 -numCpu 2 -timeOut 60
#>

  Param (
    [parameter(valuefrompipeline = $true, mandatory = $true,
    HelpMessage = "Enter a vm entity")]
      [VMware.VimAutomation.ViCore.Impl.V1.Inventory.VirtualMachineImpl]$VM,
    [int64]$memoryMB,
    [int32]$numCpu,
    [Int32]$timeOut = 300,
    [switch]$force)
    
  Process {
    if ($memoryMB -or $numCpu) {
      if ((Get-VM $vm).PowerState -eq "PoweredOn") {
        $powerState = "On"
        Shutdown-VMGuest $vm -Confirm:$false | Out-Null 
      }
      $startTime = Get-Date
      While (((Get-VM $vm).PowerState -eq "PoweredOn") -and (((Get-Date) - $startTime).totalseconds -lt $timeOut)) {
        Sleep -Seconds 2
      }
      if ((Get-VM $vm).PowerState -eq "PoweredOff" -or $force) {
        if ((Get-VM $vm).PowerState -eq "PoweredOn") {
          Write-Warning "The shutdown guest operation timed out"
          Write-Warning "Forcing shutdown"
          Stop-VM $VM -Confirm:$false | Out-Null
        }
        if ($memoryMB -and $numCpu) {
          Set-VM $vm -MemoryMB $MemoryMB -NumCpu $numCpu -Confirm:$false | Out-Null 
        }
        elseif ($memoryMB) {
          Set-VM $vm -MemoryMB $MemoryMB -Confirm:$false | Out-Null
        }
        elseif ($numCpu) {
          Set-VM $vm -NumCpu $numCpu -Confirm:$false | Out-Null
        }
        else {
          Write-Error "No value for -memoryMB or -numCpu supplied"
        }
        if ($powerState -eq "On") {
          Start-VM $vm | Out-Null
        }
      }
      else {
        Write-Error "The shutdown guest operation timed out"
      }
    }
    else {
      Write-Error "No value for -memoryMB or -numCpu supplied"
    }
  }
}

function Get-VMDiskMapping {
<#
.SYNOPSIS
  Creates a report to match Windows disk numbers and their
  virtual disk counterparts.
.DESCRIPTION
  This function creates an overview of the virtual machine's
  virtual disks and their Windows counterparts.
.NOTES
  Source:  Automating vSphere Administration
  Authors: Luc Dekens, Arnim van Lieshout, Jonathan Medd,
           Alan Renouf, Glenn Sizemore
.PARAMETER VM
  Specify the virtual machine to report on.
.PARAMETER HostCredential
  Specify a PSCredential object containing the credentials you
  want to use for authenticating with the host.
.PARAMETER GuestCredential
  Specify a PSCredential object containing the credentials you
  want to use for authenticating with the VM guest OS.
.EXAMPLE
  PS> Get-VM VM001 | Get-VMDiskMapping
.EXAMPLE
  PS> Get-VM VM001 | Get-VMDiskMapping -hostCredential $hostCred -guestCredential $guestCred | Out-GridView
#>

  Param (
    [parameter(valuefrompipeline = $true, mandatory = $true,
    HelpMessage = "Enter a vm entity")]
      [VMware.VimAutomation.ViCore.Impl.V1.Inventory.VirtualMachineImpl]$VM,
    [Parameter(Mandatory = $true,
    HelpMessage = "Enter a PSCredential object for the host")]
      [System.Management.Automation.PSCredential]$hostCredential,
    [Parameter(Mandatory = $true,
    HelpMessage = "Enter a PSCredential object for the guest")]
      [System.Management.Automation.PSCredential]$guestCredential)
    
  $diskInfo= @()
#Create vbs scriptfile
  $FileName = [System.IO.Path]::GetTempFileName()
'Set objReg = GetObject("winmgmts:{impersonationLevel=impersonate}!\\.\root\default:StdRegProv")' > $filename
'Set objWMI = GetObject("winmgmts:{impersonationLevel=impersonate}!\\.\root\cimv2")' >> $filename
'Set colPCISlotNumber = CreateObject("Scripting.Dictionary")' >> $filename
'objReg.EnumKey &H80000002,"SYSTEM\CurrentControlSet\Enum\PCI", colHardwareId' >> $filename
'For Each HardwareId In colHardwareId' >> $filename
'  objReg.EnumKey &H80000002,"SYSTEM\CurrentControlSet\Enum\PCI\" & HardwareId, colControllerId' >> $filename
'  For Each ControllerId In colControllerId' >> $filename
'    objReg.GetDWORDValue &H80000002,"SYSTEM\CurrentControlSet\Enum\PCI\" & HardwareId & "\" & ControllerId, "UINumber", dwUINumber' >> $filename
'    colPCISlotNumber.Add "PCI\" & UCase(HardwareId) & "\" & UCase(ControllerId), dwUINumber' >> $filename
'  Next' >> $filename
'Next' >> $filename
'Set colDiskDrive = objWMI.ExecQuery("Select * from Win32_DiskDrive")' >> $filename
'Set colSCSIControllerDevice = objWMI.ExecQuery("Select * from Win32_SCSIControllerDevice")' >> $filename
'WScript.Echo "DiskPNPDeviceId,Index,SCSIPort,SCSITargetId,Size,CtrlPNPDeviceId,CtrlPCISlotNumber"' >> $filename
'For Each Disk in colDiskDrive' >> $filename
'  For Each item in colSCSIControllerDevice' >> $filename
'    If Replace(Split(item.Dependent,chr(34))(1),"\\","\") = Disk.PNPDeviceId Then' >> $filename
'      CtrlPNPDeviceId = UCase(Replace(Split(item.Antecedent,chr(34))(1),"\\","\"))' >> $filename
'      Exit For' >> $filename
'    End If' >> $filename
'  Next' >> $filename
'  WScript.Echo Disk.PNPDeviceId & "," & Disk.Index & "," & Disk.SCSIPort & "," & Disk.SCSITargetId & "," & Disk.Size & "," & CtrlPNPDeviceId & "," & colPCISlotNumber.Item(CtrlPNPDeviceId)' >> $filename
'Next' >> $filename
#Determine location to copy script to
  $temp = Invoke-VMScript "echo %temp%" -vm $VM -HostCredential $hostCredential -GuestCredential $guestCredential -ScriptType "bat"
  $destFileName = $temp.Trim("`r`n") + "\guestScsiInfo.vbs"
  Copy-VMGuestFile -Source $FileName -Destination $destFileName -VM $VM -LocalToGuest -HostCredential $hostCredential -GuestCredential $guestCredential
  Remove-Item $FileName
#Get Windows disk info
  $error.Clear()
  $Out = Invoke-VMScript "cscript /nologo $destFileName && del $destFileName" `
    -vm $VM -HostCredential $hostCredential `
    -GuestCredential $guestCredential -ScriptType "bat"
  if (!$error -and $out) {
#Export plaintext Windows disk info to temporary file and 
#import it again using the Import-Csv CmdLet
    $FileName = [System.IO.Path]::GetTempFileName()
    $Out > $FileName
    $WinDisks = Import-Csv $FileName
    Remove-Item $FileName
#Determine SCSIPort offset
    $portOffset = ($WinDisks | ?{$_.SCSIPort} | Measure-Object -Property SCSIPort -Minimum).Minimum
#All entries that don't match any known pciSlotNumber are
#attached to scsi0. Change these entries to the pciSlotnumber
#of scsi0
    $scsi0pciSlotNumber = ($VM.Extensiondata.Config.ExtraConfig | ?{$_.key -like "scsi0.pciSlotNumber"}).value
    $scsiPciSlotNumbers= @()
    $VM.Extensiondata.Config.ExtraConfig | ?{$_.key -like "scsi?.pciSlotNumber"} | %{$scsiPciSlotNumbers += $_.value}
    $WinDisks | %{if ($scsiPciSlotNumbers -notcontains $_.CtrlPCISlotNumber) {$_.CtrlPCISlotNumber = ($VM.ExtensionData.Config.Extraconfig | ?{$_.key -like "scsi0.pciSlotNumber"}).value}}
#Create DiskMapping table
    foreach ($VirtualSCSIController in ($VM.Extensiondata.Config.Hardware.Device | where {$_.DeviceInfo.Label -match "SCSI Controller"})) {
      foreach ($VirtualDiskDevice in ($VM.Extensiondata.Config.Hardware.Device | where {$_.ControllerKey -eq $VirtualSCSIController.Key})) {
        $VirtualDisk = "" | Select VMSCSIController, VMDiskName, SCSI_Id, VMDiskFile, VMDiskSizeGB, RawDeviceName, LunUuid, WindowsDisk, WindowsDiskSizeGB
        $VirtualDisk.VMSCSIController = $VirtualSCSIController.DeviceInfo.Label
        $VirtualDisk.VMDiskName = $VirtualDiskDevice.DeviceInfo.Label
        $VirtualDisk.SCSI_Id = "$($VirtualSCSIController.BusNumber) : $($VirtualDiskDevice.UnitNumber)"
        $VirtualDisk.VMDiskFile = $VirtualDiskDevice.Backing.FileName
        $VirtualDisk.VMDiskSizeGB = $VirtualDiskDevice.CapacityInKB * 1KB / 1GB
        $VirtualDisk.RawDeviceName = $VirtualDiskDevice.Backing.DeviceName
        $VirtualDisk.LunUuid = $VirtualDiskDevice.Backing.LunUuid
#Match disks
        if  ($vm.version -lt "v7") {
#For hardware v4 match disks based on controller's SCSIPort and
#disk's SCSITargetId.
#Not supported with mixed scsi adapter types.
          $DiskMatch = $WinDisks | ?{($_.SCSIPort - $portOffset) -eq $VirtualSCSIController.BusNumber -and $_.SCSITargetID -eq $VirtualDiskDevice.UnitNumber}
        }
        else {
#For hardware v7 match disks based on controller's pciSlotNumber
#and disk's SCSITargetId
          $DiskMatch = $WinDisks | ?{$_.CtrlPCISlotNumber -eq ($VM.Extensiondata.Config.Extraconfig | ?{$_.key -match "scsi$($VirtualSCSIController.BusNumber).pcislotnumber"}).value -and $_.SCSITargetID -eq $VirtualDiskDevice.UnitNumber}
        }
        if ($DiskMatch){
          $VirtualDisk.WindowsDisk = "Disk $($DiskMatch.Index)"
          $VirtualDisk.WindowsDiskSizeGB = $DiskMatch.Size / 1GB
        }
        else {Write-Warning "No matching Windows disk found for SCSI id $($virtualDisk.SCSI_Id)"}
      $diskInfo += $virtualDisk
      }
    }
    $diskInfo
  }
  else {Write-Error "Error Retrieving Windows disk info from guest"}
}

function Delete-HardDisk {
<#
.SYNOPSIS
  deletes the specified virtual hard disks
.DESCRIPTION
  Removes the specified virtual hard disks from the virtual
  machine and deletes the files from the datastore
.NOTES
  Source:  Automating vSphere Administration
  Authors: Luc Dekens, Arnim van Lieshout, Jonathan Medd,
           Alan Renouf, Glenn Sizemore
.PARAMETER HardDisk
  Specify the hard disks you want to remove
.EXAMPLE
  PS> Get-HardDisk -VM $vm | Delete-HardDisk
.EXAMPLE
  PS> Get-VM VM001 | Get-HardDisk | ?{$_.Name -eq "Hard disk 2"} | Delete-HardDisk
#>
  
  Param (
    [parameter(valuefrompipeline = $true, mandatory = $true,
    HelpMessage = "Enter a hard disk entity")]
      [VMware.VimAutomation.ViCore.Types.V1.VirtualDevice.HardDisk]$hardDisk)

  process {
    $spec = New-Object VMware.Vim.VirtualMachineConfigSpec
    $spec.deviceChange = New-Object VMware.Vim.VirtualDeviceConfigSpec[] (1)
    $spec.deviceChange[0] = New-Object VMware.Vim.VirtualDeviceConfigSpec
    $spec.deviceChange[0].operation = "remove"
    $spec.deviceChange[0].fileOperation = "destroy"
    $spec.deviceChange[0].device = New-Object VMware.Vim.VirtualDisk
    $spec.deviceChange[0].device.key = $hardDisk.ExtensionData.Key

    $vm = Get-View -Id $hardDisk.ParentID
    $vm.ReconfigVM_Task($spec)
  }
}

function Set-ThinDisk {
<#
.SYNOPSIS
  Converts a thick hard disk to a thin provisioned
  hard disk inplace
.DESCRIPTION
  Makes a thin provisioned copy of a thick hard disk on the same
  datastore and configures the virtual machine to use the thin
  provisioned copy
.NOTES
  Source:  Automating vSphere Administration
  Authors: Luc Dekens, Arnim van Lieshout, Jonathan Medd,
           Alan Renouf, Glenn Sizemore
.PARAMETER HardDisk
  Specify the hard disks you want to convert
.PARAMETER credential
  A PSCredential object used to authenticate the VMHost server
.PARAMETER user
  The user account used to authenticate the VMHost server
.PARAMETER password
  The password for the account specified by the -User parameter
.PARAMETER replace
  Optional parameter to delete the original thick file
.EXAMPLE
  PS> Get-VM VM001 | Get-HardDisk | Set-ThinDisk -Credentials $hostCred
.EXAMPLE
  PS> $hd = Get-VM VM001 | Get-HardDisk | ?{$_.Name -eq "Hard disk 2"} 
  PS> Set-ThinDisk -hardDisk $hd -user "root" -password "password" -replace
#>
  Param (
    [parameter(valuefrompipeline = $true, mandatory = $true,
    HelpMessage = "Enter a hard disk entity")]
      [VMware.VimAutomation.ViCore.Types.V1.VirtualDevice.HardDisk]$hardDisk,
    [Parameter(Mandatory = $true, ParameterSetName = "cred",
    HelpMessage = "Enter a PSCredential object")]
      [System.Management.Automation.PSCredential]$credential,
    [Parameter(ParameterSetName = "user")]
    [ValidateNotNullOrEmpty()]
      [string]$user = "root",
    [Parameter(Mandatory = $true, ParameterSetName = "user",
    HelpMessage = "Enter the root account password")]
      [string]$password,
      [switch]$replace)

  process {
    if ($hardDisk.Parent.PowerState -eq "PoweredOff") {
      if ($hardDisk.StorageFormat -ne "Thin") {
        if ($credential) {
          $esxHost = Connect-VIServer -Server $hardDisk.Parent.host.name -Credential $credential -NotDefault
        }
        else {
          $esxHost = Connect-VIServer -Server $hardDisk.Parent.host.name -User $user -Password $password -NotDefault
        }
        $thinFile = $hardDisk.Filename.Replace("/","/thin_")
        $datastore = $hardDisk.Filename.split('[')[1].split(']')[0]
        $esxHardDisk = Get-HardDisk -server $esxHost -Datastore $datastore -DatastorePath $hardDisk.Filename
        Copy-HardDisk -HardDisk $esxHardDisk -DestinationPath $thinFile -DestinationStorageFormat "thin" | Out-Null
        Disconnect-VIServer $esxHost -Confirm:$false

        $spec = New-Object VMware.Vim.VirtualMachineConfigSpec
        $spec.deviceChange = New-Object VMware.Vim.VirtualDeviceConfigSpec[] (2)
        $spec.deviceChange[0] = New-Object VMware.Vim.VirtualDeviceConfigSpec
        $spec.deviceChange[0].operation = "remove"
        if ($replace) {
          $spec.deviceChange[0].fileOperation = "destroy"
        }
        $spec.deviceChange[0].device = $hardDisk.ExtensionData

        $spec.deviceChange[1] = New-Object VMware.Vim.VirtualDeviceConfigSpec
        $spec.deviceChange[1].operation = "add"
        $spec.deviceChange[1].device = New-Object VMware.Vim.VirtualDisk
        $spec.deviceChange[1].device.key = -100
        $spec.deviceChange[1].device.backing = New-Object VMware.Vim.VirtualDiskFlatVer2BackingInfo
        $spec.deviceChange[1].device.backing.fileName = $thinFile
        $spec.deviceChange[1].device.backing.diskMode = "persistent"
        $spec.deviceChange[1].device.backing.thinProvisioned = $true
        $spec.deviceChange[1].device.controllerKey = $hardDisk.ExtensionData.ControllerKey
        $spec.deviceChange[1].device.unitNumber = $hardDisk.ExtensionData.UnitNumber

        $vm = Get-View -Id $hardDisk.ParentID
        $vm.ReconfigVM_Task($spec) | Out-Null
      }
      else {
        Write-Error "Virtual disk already thin provisioned"
      }
    }
    else {
      Write-Error "Virtual machine must be powered off"
    }
  }
}
Function Rename-LocalUser {
<#
.SYNOPSIS
  Renames a local user account using WMI
.DESCRIPTION
  This function renames a local user account using WMI on
  the (remote) computer specified by the Computer parameter
.NOTES
  Source:  Automating vSphere Administration
  Authors: Luc Dekens, Arnim van Lieshout, Jonathan Medd,
           Alan Renouf, Glenn Sizemore
.PARAMETER userName
  The name of the local user account to rename
.PARAMETER newUserName
  The new name of the local user account
.PARAMETER computer
  The name of the computer to rename the local user account on.
  To run the operation on the local computer
  use 'localhost' or '.' as computer name
.EXAMPLE
  PS> Rename-LocalUser "Administrator" "GoodForNothing" "."
#>

  param(
    [parameter(mandatory = $true, position=1,
      HelpMessage = "Enter a local user account name")]
    [String]$userName,
    [parameter(mandatory = $true, position=2,
      HelpMessage = "Enter a new user name")]
    [String]$newUserName,
    [parameter(mandatory = $true, position=3,
      HelpMessage = "Enter a computer name")]
    [String]$Computer)
  
  $user = Get-WmiObject -Query "Select * From Win32_UserAccount
    Where LocalAccount = True And 
    Name = '$userName'" -ComputerName $computer
  
  If ($user) {
    Write-Host -ForegroundColor Yellow "User $userName found on $computer"
    $result = $user | %{$_.Rename("$newUserName")}
    If ($result.ReturnValue -eq 0) {
      Write-Host -ForegroundColor Yellow "User $userName successfully renamed to $newUserName"
    }
    else {
      Write-Host -ForegroundColor Red "Rename operation failed.
Errorcode $($result.ReturnValue)"
    }
  }
}

Function Check-Service {
<#
.SYNOPSIS
  Checks the state of a service using PowerShell remoting
.DESCRIPTION
  This function checks the state of a service using
  PowerShell remoting. The optional restart switch can be used
  to restart a service if it is stopped.
.NOTES
  Source:  Automating vSphere Administration
  Authors: Luc Dekens, Arnim van Lieshout, Jonathan Medd,
           Alan Renouf, Glenn Sizemore
.PARAMETER Computer
  One or more computer names to check the service on
.PARAMETER Service
  One or more service names to check
.PARAMETER Start
  Optional parameter to start a stopped service
.PARAMETER Restart
  Optional parameter to restart a service
.EXAMPLE
  PS> Check-Service -Computer VM001 -Service wuauserv
#>

  Param(
    [parameter(mandatory = $true,
    HelpMessage = "Enter a computer name")]
    [string]$Computer,
    [parameter(mandatory = $true,
    HelpMessage = "Enter a service name")]
    [string]$Service,
    [switch]$Start,
    [switch]$Restart)
  
  $report=@()
#establish a persistent connection
  $session = New-PSSession $Computer
  $remoteService = Invoke-Command ?Session $session -ScriptBlock {
    param($ServiceName)
    $localService = Get-Service $ServiceName
    $localService
  } -ArgumentList $Service
  If ($Start -and $remoteService.Status -eq "Stopped") {
    Invoke-Command ?Session $session -ScriptBlock {
        $localService.Start()
    }
    $remoteService | Add-Member -MemberType NoteProperty -Name Started -Value $True
  }
  If ($Restart) {
    Invoke-Command ?Session $session -ScriptBlock {
      $localService.stop()
      $localService.WaitForStatus("Stopped")
      $localService.start()
    }
    $remoteService | Add-Member -MemberType NoteProperty -Name Restarted -Value $True
  }
  $report += $remoteService
#close persistent connection
  Remove-PSSession $session
  $report
}

Function Evacuate-VMHost {
<#
.SYNOPSIS
  Puts host into maintenance mode and moves all VMs on the host
  to other members in the same cluster
.DESCRIPTION
  This function puts a host in maintenance mode and moves all
  VMs from the VMHost randomly to other hosts in the cluster.
  If -TargetHost is specified, all VMs are moved to this
  TargetHost instead of random cluster members.
.NOTES
  Source:  Automating vSphere Administration
  Authors: Luc Dekens, Arnim van Lieshout, Jonathan Medd,
           Alan Renouf, Glenn Sizemore
.PARAMETER VMHost
  The source host to put into maintenance mode
.PARAMETER TargetHost
  Optional target host
.EXAMPLE
  PS> Evacuate-VMHost -VMHost ESX01
.EXAMPLE
  PS> Evacuate-VMHost -VMHost ESX01 -TargetHost ESX02
#>

  Param(
      [parameter(mandatory = $true, position=1,
    HelpMessage = "Enter a source server")]
    [PSObject]$VMHost,
    [PSObject]$TargetHost)
    
  if ("String","VMHostImpl" -notcontains $VMHost.GetType().Name) {
    throw "No valid type for -VMHost specified"
  }
  if ($TargetHost -and "String","VMHostImpl" -notcontains $TargetHost.GetType().Name) {
    throw "No valid type for -TargetHost specified"
  }

  $sourceHost = Get-VMHost $VMHost
  if ($TargetHost) {
    $TargetHost = Get-VMHost $TargetHost
    if (!$TargetHost) {
      throw "-TargetHost cannot be found"
    }
  }
  else {
    $cluster = Get-Cluster -VMHost $sourceHost
    if (!$cluster) {
      throw "No cluster found"
    }
    $clusterHosts = $cluster | Get-VMHost | ?{$_.Name -ne $sourceHost.Name -and $_.State -eq "Connected"}
    if (!$clusterHosts) {
      throw "No valid cluster members found"
    }
  }
  
#Evacuate all VMs from host
  foreach ($vm in ($sourceHost | Get-VM)) {
    if ($TargetHost) {
      $vmDestination = $TargetHost
    }
    else {
      $vmDestination = $clusterHosts | Get-Random
    }
    Move-VM -VM $vm -Destination $vmDestination -RunAsync:$true -Confirm:$false | Out-Null
  }
  
#Put host into maintenance mode
  $sourceHost | Set-VMHost -State "Maintenance" -RunAsync:$true | Out-Null
}

Function Move-Datastore {
<#
.SYNOPSIS
  Moves all registered .vmx and .vmdk files to another datastore
.DESCRIPTION
  This function moves all registered vms from the source
  datastore to the target datastore
.NOTES
  Source:  Automating vSphere Administration
  Authors: Luc Dekens, Arnim van Lieshout, Jonathan Medd,
           Alan Renouf, Glenn Sizemore
.PARAMETER SourceDatastore
  The source datastore name or object
.PARAMETER TargetDatastore
  The target datastore name or object
.EXAMPLE
  PS> Move-Datastore -SourceDatastore "Datastore01" -TargetDatastore "Datastore02"
.EXAMPLE
  PS> Move-Datastore "Datastore01" "Datastore02"
#>

  param(
    [parameter(mandatory = $true, position=1,
    HelpMessage = "Enter a source datastore")]
    [PSObject]$SourceDatastore,
    [parameter(mandatory = $true, position=2,
    HelpMessage = "Enter a target datastore")]
    [PSObject]$TargetDatastore)

  if ("String","DatastoreImpl" -notcontains $SourceDatastore.GetType().Name) {
    throw "No valid type for -SourceDatastore specified"
  }
  if ("String","DatastoreImpl" -notcontains $TargetDatastore.GetType().Name) {
    throw "No valid type for -TargetDatastore specified"
  }
  
  $SourceDatastore = Get-Datastore $SourceDatastore
  $TargetDatastore = Get-Datastore $TargetDatastore
  foreach($vm in ($SourceDatastore | Get-VM)) {
    $configFile = $vm.ExtensionData.Config.Files.VmPathName
    $configDatastoreName = $configFile.Trim('[').Split(']')[0]
    if ($configDatastoreName -eq $SourceDatastore.Name) {
      $configDatastoreName = $TargetDatastore.Name
    }
    $spec = New-Object VMware.Vim.VirtualMachineRelocateSpec
    $dsView = Get-Datastore $configDatastoreName | Get-View
    $spec.Datastore = $dsView.MoRef
    foreach ($disk in $vm.HardDisks) {
      $diskDatastoreName= $disk.FileName.Trim('[').Split(']')[0]
      if ($diskDatastoreName -eq $SourceDatastore.Name) {
        $diskDatastoreName = $TargetDatastore.Name
      }
      $objDisk = New-Object VMware.Vim.VirtualMachineRelocateSpecDiskLocator
      $objDisk.DiskID = $disk.Id.Split('/')[1]
      $dsView = Get-Datastore $diskDatastoreName | Get-View
      $objDisk.DataStore = $dsView.MoRef
      $spec.Disk += $objDisk
    }
    $vm.ExtensionData.RelocateVM_Task($spec, "defaultPriority")
  }
}

function Get-SnapshotTree{
  param($tree, $target)
  $found = $null
  foreach($elem in $tree){
    if($elem.Snapshot.Value -eq $target.Value){
      $found = $elem
      continue
    }
  }
  if($found -eq $null -and $elem.ChildSnapshotList -ne $null){
    $found = Get-SnapshotTree $elem.ChildSnapshotList $target
  }
  return $found
}

function Get-SnapshotExtra ($snap){
  $guestName = $snap.VM #The name of the guest
  $tasknumber = 999 #Windowsize of the Task collector
  $taskMgr = Get-View TaskManager

#Create hash table. Each entry is a create snapshot task
  $report = @{}

  $filter = New-Object VMware.Vim.TaskFilterSpec
  $filter.Time = New-Object VMware.Vim.TaskFilterSpecByTime
  $filter.Time.beginTime = (($snap.Created).AddDays(-5))
  $filter.Time.timeType = "startedTime"

  $collectionImpl = Get-View ($taskMgr.CreateCollectorForTasks($filter))

  $dummy = $collectionImpl.RewindCollector
  $collection = $collectionImpl.ReadNextTasks($tasknumber)
  while($collection -ne $null){
    $collection | where {$_.DescriptionId -eq "VirtualMachine.createSnapshot" -and $_.State -eq "success" -and $_.EntityName -eq $guestName} | %{
      $row = New-Object PsObject
      $row | Add-Member -MemberType NoteProperty -Name User -Value $_.Reason.UserName
      $vm = Get-View $_.Entity
      if($vm -ne $null){ 
        $snapshot = Get-SnapshotTree $vm.Snapshot.RootSnapshotList $_.Result
        if($snapshot -ne $null){
          $key = $_.EntityName + "&" + ($snapshot.CreateTime.ToString())
          $report[$key] = $row
        }
      }
    }
    $collection = $collectionImpl.ReadNextTasks($tasknumber)
  }
  $collectionImpl.DestroyCollector()

  # Get the guest's snapshots and add the user
  $snapshotsExtra = $snap | % {
    $key = $_.vm.Name + "&" + ($_.Created.ToString())
    if($report.ContainsKey($key)){
      $_ | Add-Member -MemberType NoteProperty -Name Creator -Value $report[$key].User
    }
    $_
  }
  $snapshotsExtra
}

Function Get-ADUserObject {
<#
.SYNOPSIS
  Retrieves a user object from Active Directory
.DESCRIPTION
  This function retrieves a user object from Active Directory
  specified by the -UserName variable
.NOTES
  Source:  Automating vSphere Administration
  Authors: Luc Dekens, Arnim van Lieshout, Jonathan Medd,
           Alan Renouf, Glenn Sizemore
.PARAMETER UserName
  The SAM account name of the user object to retrieve
.EXAMPLE
  PS> Get-ADUserObject "administrator"
#>

  Param ([parameter(valuefrompipeline = $true, mandatory=$true,
    HelpMessage = "Enter a user SAM accountname")]
    [string]$userName)

  $ds = New-Object system.DirectoryServices.DirectorySearcher
  $ds.searchRoot = [ADSI]""
  $ds.searchScope = "subtree"
  $ds.filter = "(&(objectClass=user)(samAccountName=$userName))"
  $result = $ds.findOne()
  if ($result) {
    return $result.GetDirectoryEntry()
  }
}

Function Get-SnapshotCreator {
<#
.SYNOPSIS
  Retrieves the user who created the snapshot
.DESCRIPTION
  This function retrieves the user who created the snapshot
  specified by the -Snapshot parameter
.NOTES
  Source:  Automating vSphere Administration
  Authors: Luc Dekens, Arnim van Lieshout, Jonathan Medd,
           Alan Renouf, Glenn Sizemore
.PARAMETER Snapshot
  The snapshot to return the creator of
.EXAMPLE
  PS> Get-SnapshotCreator $mySnapshot
.EXAMPLE
  PS> $mySnapshot | Get-SnapshotCreator
#>

  Param ([parameter(valuefrompipeline = $true, mandatory=$true,
    HelpMessage = "Enter a snapshot entity")]
    [VMware.VimAutomation.ViCore.Impl.V1.VM.SnapshotImpl]$snapshot)
  
  $taskNumber = 100
  $taskMgr = Get-View TaskManager
  
  $filter = New-Object VMware.Vim.TaskFilterSpec
  $filter.Time = New-Object VMware.Vim.TaskFilterSpecByTime
  $filter.Time.beginTime = (($snapshot.Created).AddDays(-1))
  $filter.Time.endTime = ($snapshot.Created)
  $filter.Time.timeType = "startedTime"
  $filter.Entity = New-Object VMware.Vim.TaskFilterSpecByEntity
  $filter.Entity.Entity = $snapshot.extensiondata.vm
  $filter.state = New-Object VMware.Vim.TaskInfoState
  $filter.state = "success"

  $taskCollector = Get-View $taskMgr.CreateCollectorForTasks($filter)
  
  $taskCollector.RewindCollector | Out-Null 
  $taskCollection = $taskCollector.ReadNextTasks($taskNumber)
  $matches=@()
  while ($taskCollection) {
    $matches += $taskCollection | Where {$_.DescriptionId -eq "VirtualMachine.createSnapshot" -and $_.Result.ToString() -eq $snapshot.Id}
    $taskCollection = $taskCollector.ReadNextTasks($taskNumber)
  }
  $taskCollector.DestroyCollector() 
  $matches | %{$_.Reason.UserName}
}

function Set-VMAdvancedConfiguration{ 
<#
.SYNOPSIS
  Sets an advanced configuration setting (VMX Setting) for a VM
  or multiple VMs
.DESCRIPTION
  The function will set a VMX setting for a VM
  or multiple VMs
.NOTES
  Source:  Automating vSphere Administration
  Authors: Luc Dekens, Arnim van Lieshout, Jonathan Medd,
           Alan Renouf, Glenn Sizemore
.PARAMETER VM
  A virtual machine or multiple virtual machines
.PARAMETER Key
  The Key to use for the advanced configuration
.PARAMETER Value
  The value of the key
.EXAMPLE 1
  PS> Set-VMAdvancedConfiguration -key log.rotatesize -value 10000
#>

  param(
    [Parameter(Mandatory=$true,ValueFromPipeline=$true)]
      $vm,
    [Parameter(Mandatory=$true)]
      [String]$key,
    [Parameter(Mandatory=$true)]
      [String]$value) 

  process{ 
    $vmConfigSpec = new-object VMware.Vim.VirtualMachineConfigSpec
    $vmConfigSpec.ExtraConfig += new-object VMware.Vim.OptionValue
    $vmConfigSpec.ExtraConfig[0].key = $key
    $vmConfigSpec.ExtraConfig[0].value = $value

    foreach ($singlevm in $vm) {
      $VMview = $singlevm | get-view
      $Task = $VMview.ReconfigVM_Task($vmConfigSpec)
      Write "Set Advanced configuration for $($singleVM.Name): $key = $value"
    }
  } 
}
Function Get-OvfDetails
{
    Param(
        [Parameter(ValueFromPipeline=$true
        ,    ValueFromPipelineByPropertyName=$True)]
        [ValidateScript({Test-Path $_})]
        [ValidatePattern('.ovf$')]
        [Alias("PSPath")]
        [string]
        $Path
    )
    Begin
    {
        $pdp = New-Object VMware.Vim.OvfParseDescriptorParams
        $pdp.locale = ""
        $pdp.deploymentOption = ""
    }
    Process
    {
        $OvfM = Get-View -Id 'OvfManager-OvfManager'
        $OvfM.ParseDescriptor( `
            (Get-Content $path|Out-String),$pdp)
    }
}
Function Get-vAppStartOrder
{
  <#
  .SYNOPSIS
    Get the vApp Startup Order for a given VM
  .DESCRIPTION
    Get the vApp Startup Order for a given VM if no VM is 
    provided will return the startup order for every VM 
    in the vApp.
  .NOTES
    Source:  Automating vSphere Administration
    Authors: Luc Dekens, Arnim van Lieshout, Jonathan Medd,
           Alan Renouf, Glenn Sizemore
  .PARAMETER VM
    VM to retrieve the startup order for.
  .PARAMETER vApp
    vApp to rerieve the startup order from.
  .EXAMPLE
    Get-vApp | Get-vAppStartOrder
  .EXAMPLE
    Get-vAppStartOrder -VM (get-vm sql01)
  #>
  [cmdletbinding()]
  Param(
    [Parameter(ValueFromPipeline=$True)]
    [VMware.VimAutomation.ViCore.Impl.V1.Inventory.VirtualMachineImpl]
    $VM
  ,
    [Parameter(ValueFromPipeline=$True)]
    [VMware.VimAutomation.ViCore.Impl.V1.Inventory.VAppImpl]
    $vApp
  )
  Process
  {
    if ($VM)
    {
      Try
      {
        $vApp = Get-VIObjectByVIView $vm.ExtensionData.ParentVApp
      }
      catch
      {
        Write-Warning "$($VM.name) doesn't belong to a vApp."
        continue;
      }
    }
    Elseif (-Not $vApp)
    {
      Write-Warning 'vApp was not specified'
      break;
    }
    $vApp.ExtensionData.VAppConfig.EntityConfig |
      Where-Object {$_.Key -match $VM.ID} |
      Select-Object @{
        name='VM'
        Expression={Get-VIObjectByVIView $_.Key}
      },
      @{
        name='vApp'
        Expression={$vApp.name}
      },
      'StartOrder','StartDelay',
      'WaitingForGuest','StartAction',
      'StopDelay','StopAction',
      @{
        name='DestroyWithParent'
        Expression={IF ($_.DestroyWithParent -eq $null){
            $False
          }
          else
          {
            $_.DestroyWithParent
          }
        }
      }
  }
}

Function Set-vAppStartOrder
{
  <#
  .SYNOPSIS
    Set the vApp Startup Order for a given VM/vApp
  .DESCRIPTION
    Set the vApp Startup Order for a given VM/vApp
  .NOTES
    Source:  Automating vSphere Administration
    Authors: Luc Dekens, Arnim van Lieshout, Jonathan Medd,
           Alan Renouf, Glenn Sizemore
  .PARAMETER VM
    VM to modify the startup order for.
  .PARAMETER vApp
    vApp to modify the startup order for.
  .PARAMETER StartOrder
    Specifies the start order for this entity. Entities are
    started from lower numbers to higher-numbers and 
    reverse on shutdown. Multiple entities with the same 
    start-order can be started in parallel and the order is 
    unspecified. This value must be 0 or higher.
  .PARAMETER StartDelay
    Delay in seconds before continuing with the next entity 
    in the order of entities to be started
  .PARAMETER WaitingForGuest
    Determines if the virtual machine should start after 
    receiving a heartbeat, from the guest. When a virtual 
    machine is next in the start order, the system either 
    waits a specified period of time for a virtual machine
    to power on or it waits until it receives a successful
    heartbeat from a powered on virtual machine. By 
    default, this is set to false. This property has no 
    effect for vApps.
  .PARAMETER StartAction
    How to start the entity. Valid settings are none or 
    powerOn. If set to none, then the entity does not 
    participate in auto-start.
  .PARAMETER StopDelay
    Delay in seconds before continuing with the next entity
    in the order sequence. This is only used if the stopAction 
    is guestShutdown.
  .PARAMETER StopAction
    Defines the stop action for the entity. Can be set to none, 
    powerOff, guestShutdown, or suspend. If set to none, then 
    the entity does not participate in auto-stop.
  .PARAMETER DestroyWithParent
    ether the entity should be removed, when this vApp is 
    removed. This is only set for linked children.
  .EXAMPLE
    Get-vApp | Get-vAppStartOrder
  .EXAMPLE
    Get-vAppStartOrder -VM (get-vm sql01)
  #>
  [CmdletBinding(SupportsShouldProcess=$true,
    DefaultParameterSetName='ByVM')]
  Param(
    [Parameter(Mandatory=$true
    ,   ValueFromPipelineByPropertyName=$true
    ,   ValueFromPipeline=$True
    ,   ParameterSetName='ByVM'
    )]
    [VMware.VimAutomation.ViCore.Impl.V1.Inventory.VirtualMachineImpl]
    $VM
  ,   
    [Parameter(ValueFromPipeline=$True
    ,   ParameterSetName='ByvApp'
    )]
    [VMware.VimAutomation.ViCore.Impl.V1.Inventory.VAppImpl]
    $vApp
  ,
    [Parameter(ValueFromPipelineByPropertyName=$true
    ,   ParameterSetName='ByvApp'
    )]
    [Parameter(ValueFromPipelineByPropertyName=$true
    ,   ParameterSetName='ByVM'
    )]
    [int]
    $StartOrder
  ,
    [Parameter(ValueFromPipelineByPropertyName=$true
    ,   ParameterSetName='ByvApp'
    )]
    [Parameter(ValueFromPipelineByPropertyName=$true
    ,   ParameterSetName='ByVM'
    )]
    [int]
    $StartDelay
  ,
    [Parameter(ValueFromPipelineByPropertyName=$true
    ,   ParameterSetName='ByVM'
    )]
    [bool]
    $WaitingForGuest
  ,
    [Parameter(ValueFromPipelineByPropertyName=$true
    ,   ParameterSetName='ByvApp'
    )]
    [Parameter(ValueFromPipelineByPropertyName=$true
    ,   ParameterSetName='ByVM'
    )]
    [ValidateSet("none","powerOn")]
    [string]
    $StartAction
  ,
    [Parameter(ValueFromPipelineByPropertyName=$true
    ,   ParameterSetName='ByvApp'
    )]
    [Parameter(ValueFromPipelineByPropertyName=$true
    ,   ParameterSetName='ByVM'
    )]
    [int]
    $StopDelay
  ,
    [Parameter(ValueFromPipelineByPropertyName=$true
    ,   ParameterSetName='ByvApp'
    )]
    [Parameter(ValueFromPipelineByPropertyName=$true
    ,   ParameterSetName='ByVM'
    )]
    [ValidateSet('none','powerOff','guestShutdown','suspend')]
    [string]
    $StopAction
  ,
    [Parameter(ValueFromPipelineByPropertyName=$true
    ,   ParameterSetName='ByvApp'
    )]
    [bool]
    $DestroyWithParent
  )
  process 
  {

    Try
    {
      $vApp = Get-VIObjectByVIView $vm.ExtensionData.ParentVApp
    }
    catch
    {
      Write-Warning "$($VM.name) doesn't belong to a vApp."
      continue;
    }
    $EntityConfig = $vApp.ExtensionData.VAppConfig.EntityConfig
    
    $spec = New-Object VMware.Vim.VAppConfigSpec
    $spec.entityConfig = `
      Foreach ($Conf in ($EntityConfig.GetEnumerator()))
      {
        If ($Conf.Key.ToString() -eq $VM.ID.tostring())
        {
          $msg = "Setting $($VM.Name) start order to:"
          Switch ($PSCmdlet.MyInvocation.BoundParameters.keys)
          {
            'StartOrder'
            {
              $msg = "{0} StartOrder:{1}" -f $msg, 
                $StartOrder
              $Conf.StartOrder = $StartOrder
            }
            'StartDelay'
            {
              $msg = "{0} StartDelay:{1}" -f $msg, 
                $StartDelay
              $Conf.StartDelay = $StartDelay
            }
            'WaitingForGuest'
            {
              $msg = "{0} WaitingForGuest:{1}" -f $msg, 
                $WaitingForGuest
              $Conf.WaitingForGuest = $WaitingForGuest
            }
            'StartAction'
            {
              $msg = "{0} StartAction:{1}" -f $msg, 
                $StartAction
              $Conf.StartAction = $StartAction
            }
            'StopDelay'
            {
              $msg = "{0} StopDelay:{1}" -f $msg, 
                $StopDelay
              $Conf.StopDelay = $StopDelay
            }
            'StopAction'
            {
              $msg = "{0} StopAction:{1}" -f $msg, 
                $StopAction
              $Conf.StopAction = $StopAction
            }
            'DestroyWithParent'
            {
              $msg = "{0} DestroyWithParent:{1}" -f $msg, 
                $DestroyWithParent
              $Conf.DestroyWithParent = $DestroyWithParent
            }
          }
        }
        $conf
      }
    If ($pscmdlet.shouldprocess($vApp.Name, $msg))
    {
      $vApp.ExtensionData.UpdateVAppConfig($spec)
    }
  }
}

Function Get-IPPool
{
    <#
    .SYNOPSIS
        Get existing IP Pools from vCenter
    .DESCRIPTION
        Get existing IP Pools from vCenter
    .NOTES
        Source:  Automating vSphere Administration
        Authors: Luc Dekens, Arnim van Lieshout, Jonathan Medd,
           Alan Renouf, Glenn Sizemore
    .PARAMETER Datacenter
        Datacenter to query for IP Pools.
    .EXAMPLE
        Get-Datacenter | Get-IPPool
    #>
    [cmdletbinding()]
    Param(
        [Parameter(ValueFromPipeline=$True
        ,   ValueFromPipelineByPropertyName=$True)]
        [VMware.VimAutomation.ViCore.Impl.V1.Inventory.DatacenterImpl[]]
        $Datacenter = (Get-Datacenter)
    ,
        [Parameter(ValueFromPipeline=$True
        ,   ValueFromPipelineByPropertyName=$True)]
        [String]
        $Name = "*"
    )
    Process
    {
        Foreach ($dc in $Datacenter)
        {
            $IPPoolManager = Get-View `
				-Id 'IpPoolManager-IpPoolManager'
            $IPPoolManager.QueryIpPools($dc.ID) | 
                Where-Object {$_.Name -like $name}| %{
                New-Object PSOBject -Property @{
                    'Name' = $_.Name
                    'DnsDomain' = $_.DNSDomain
                    'DNSSearchPath' = $_.DNSSearchPath
                    'HostPrefix' = $_.HostPrefix
                    'HttpProxy' = $_.HttpProxy
                    'NetworkAssociation' = $_.NetworkAssociation
                    'IPv4SubnetAddress' = `
						$_.ipv4Config.SubnetAddress
                    'IPv4Netmask'=$_.ipv4Config.netmask
                    'IPv4Gateway'=$_.ipv4Config.Gateway
                    'IPv4Range'=$_.ipv4Config.Range
                    'IPv4DNS'=$_.ipv4Config.DNS
                    'IPv4DHCP'=$_.ipv4Config.DhcpServerAvailable
                    'IPv4IpPoolEnabled' = `
						$_.ipv4Config.IpPoolEnabled
                    'IPv6SubnetAddress' = `
						$_.ipv6Config.SubnetAddress
                    'IPv6Netmask'=$_.ipv6Config.netmask
                    'IPv6Gateway'=$_.ipv6Config.Gateway
                    'IPv6Range'=$_.ipv6Config.Range
                    'IPv6DNS'=$_.ipv6Config.DNS
                    'IPv6DHCP'=$_.ipv6Config.DhcpServerAvailable
                    'IPv6IpPoolEnabled' = `
						$_.ipv6Config.IpPoolEnabled
                    'Datacenter'=$dc
                }
            }
        }
    }
}

Function New-IpPool
{
    <#
    .SYNOPSIS
        Create a new IP Pool within vCenter
    .DESCRIPTION
        Create a new IP Pool within vCenter
    .NOTES
        Source:  Automating vSphere Administration
        Authors: Luc Dekens, Arnim van Lieshout, Jonathan Medd,
           Alan Renouf, Glenn Sizemore
    .PARAMETER Datacenter
        Datacenter to create the new IP Pool in.
    .PARAMETER Name
        Pool name. Must be unique. 
    .PARAMETER DnsDomain
        DNS Domain. For example, vmware.com. This can be an 
        empty string if no domain is configured. 
    .PARAMETER DNSSearchPath
        DNS Search Path. For example, eng.vmware.com;vmware.com
    .PARAMETER HostPrefix
        Prefix for hostnames.
    .PARAMETER HttpProxy
        The HTTP proxy to use on this network
    .PARAMETER NetworkAssociation
        The networks that are associated with this IP pool.
        
        Use the Get-Network function to get the objects this 
        parameter requires.
    .PARAMETER IPv4SubnetAddress
        Address of the subnet.
    .PARAMETER IPv4Netmask
        Netmask
    .PARAMETER IPv4Gateway
        Gateway. This can be an empty string
    .PARAMETER IPv4Range
        IP range. This is specified as a set of ranges 
        separated with commas. One range is given by a start 
        address, a hash (#), and the length of the range.
        For example:
        192.0.2.235#20 = IPv4 range 192.0.2.235-192.0.2.254
        192.0.2.0#24 = IPv4 range 192.0.2.1-192.0.2.254
    .PARAMETER IPv4DNS
        DNS servers 
    .PARAMETER IPv4DHCP
        Whether a DHCP server is available on this network.
    .PARAMETER IPv4IpPoolEnabled
        IP addresses can only be allocated from the range if 
        the IP pool is enabled. 
    .PARAMETER IPv6SubnetAddress
        Address of the subnet.
    .PARAMETER IPv6Netmask
        Netmask
    .PARAMETER IPv6Gateway
        Gateway. This can be an empty string
    .PARAMETER IPv6Range
        IP range. This is specified as a set of ranges 
        separated with commas. One range is given by a start
        address, a hash (#), and the length of the range.
        For example:
        2001::7334 # 20 = IPv6 range 2001::7334 - 2001::7347
    .PARAMETER IPv6DNS
        DNS servers 
    .PARAMETER IPv6DHCP
        Whether a DHCP server is available on this network.
    .PARAMETER IPv6IpPoolEnabled
        IP addresses can only be allocated from the range if 
        the IP pool is enabled.     
    .EXAMPLE
        
    #>
    [cmdletbinding()]
    Param(
        [Parameter(Mandatory=$True
        ,   ValueFromPipeline=$True
        ,   ValueFromPipelineByPropertyName=$True)]
        [VMware.VimAutomation.ViCore.Impl.V1.Inventory.DatacenterImpl]
        $Datacenter
    ,   [Parameter(Mandatory=$true
        ,   ValueFromPipelineByPropertyName=$True)]
        [String]
        $Name
    ,   [Parameter(ValueFromPipelineByPropertyName=$True)]
        [String]
        $DnsDomain = ""
    ,   [Parameter(ValueFromPipelineByPropertyName=$True)]
        [String[]]
        $DNSSearchPath = ""
    ,   [Parameter(ValueFromPipelineByPropertyName=$True)]
        [String]
        $HostPrefix = ""
    ,   [Parameter(ValueFromPipelineByPropertyName=$True)]
        [String]
        $HttpProxy = ""
    ,   [Parameter(ValueFromPipeline=$True
        ,    ValueFromPipelineByPropertyName=$True)]
        [VMware.Vim.IpPoolAssociation[]]
        $NetworkAssociation
    ,   [Parameter(ValueFromPipelineByPropertyName=$True)]
        [String]
        $IPv4SubnetAddress = ''
    ,   [Parameter(ValueFromPipelineByPropertyName=$True)]
        [String]
        $IPv4Netmask = '255.255.255.0'
    ,   [Parameter(ValueFromPipelineByPropertyName=$True)]
        [String]
        $IPv4Gateway = ''
    ,   [Parameter(ValueFromPipelineByPropertyName=$True)]
        [String]
        $IPv4Range
    ,   [Parameter(ValueFromPipelineByPropertyName=$True)]
        [String[]]
        $IPv4DNS = @("")
    ,   [Parameter(ValueFromPipelineByPropertyName=$True)]
        [bool]
        $IPv4DHCP = $false
    ,   [Parameter(ValueFromPipelineByPropertyName=$True)]
        [bool]
        $IPv4IpPoolEnabled = $false
    ,   [Parameter(ValueFromPipelineByPropertyName=$True)]
        [String]
        $IPv6SubnetAddress = ''
    ,   [Parameter(ValueFromPipelineByPropertyName=$True)]
        [String]
        $IPv6Netmask = "ffff:ffff:ffff:ffff:ffff:ffff::"
    ,   [Parameter(ValueFromPipelineByPropertyName=$True)]
        [String]
        $IPv6Gateway = ""
    ,   [Parameter(ValueFromPipelineByPropertyName=$True)]
        [String]
        $IPv6Range
    ,   [Parameter(ValueFromPipelineByPropertyName=$True)]
        [String[]]
        $IPv6DNS = @()
    ,   [Parameter(ValueFromPipelineByPropertyName=$True)]
        [bool]
        $IPv6DHCP = $false
    ,   [Parameter(ValueFromPipelineByPropertyName=$True)]
        [bool]
        $IPv6IpPoolEnabled = $false
    )
    Process
    {
        $pool = New-Object VMware.Vim.IpPool
        $pool.name = $Name
        $pool.ipv4Config = `
            New-Object VMware.Vim.IpPoolIpPoolConfigInfo
        $pool.ipv4Config.subnetAddress = $IPv4SubnetAddress
        $pool.ipv4Config.netmask = $IPv4Netmask
        $pool.ipv4Config.gateway = $IPv4Gateway
        $pool.ipv4Config.dns = $IPv4DNS
        $pool.ipv4Config.dhcpServerAvailable = $IPv4DHCP
        $pool.ipv4Config.ipPoolEnabled = $IPv4IpPoolEnabled
        $pool.ipv6Config = `
            New-Object VMware.Vim.IpPoolIpPoolConfigInfo
        IF ($IPv4Range)
        {
            $pool.ipv4Config.range = $IPv4Range
        }
        $pool.ipv6Config.subnetAddress = $IPv6SubnetAddress
        $pool.ipv6Config.netmask = $IPv6Netmask
        $pool.ipv6Config.gateway = $IPv6Gateway
        $pool.ipv6Config.dns = $IPv6DNS
        $pool.ipv6Config.dhcpServerAvailable = $IPv6DHCP
        $pool.ipv6Config.ipPoolEnabled = $IPv6IpPoolEnabled
        IF ($IPv6Range)
        {
            $pool.ipv6Config.range = $IPv6Range
        }
        $pool.dnsDomain = $DnsDomain
        $pool.dnsSearchPath = $DNSSearchPath
        $pool.hostPrefix = $HostPrefix
        $pool.httpProxy = $HttpProxy
        if ($NetworkAssociation)
        {
            $pool.NetworkAssociation = $NetworkAssociation
        }
        $IpPoolManager = Get-View 'IpPoolManager-IpPoolManager'
        $IpPoolManager.CreateIpPool($DataCenter.id, $pool) |
            Out-Null
        if ($?)
        {
            Get-IPPool -Datacenter $DataCenter -Name $Name
        }
    }
}

Function Get-Network
{
    <#
    .SYNOPSIS
        Get networks registered in vcenter
    .DESCRIPTION
        Get networks registered in vcenter
    .NOTES
        Source:  Automating vSphere Administration
        Authors: Luc Dekens, Arnim van Lieshout, Jonathan Medd,
           Alan Renouf, Glenn Sizemore
    .PARAMETER name
        Only return networks that match name
    .EXAMPLE
        Get-Network -Name 10.10.10.0
    #>
    [cmdletbinding(DefaultParameterSetName='name')]
    Param(
        [Parameter(ParameterSetName='name'
        ,   ValueFromPipeline=$True
        ,   ValueFromPipelineByPropertyName=$True)]
        [String]
        $Name = "*"
    ,   [Parameter(ParameterSetName='MoRef'
        ,   ValueFromPipeline=$True
        ,   ValueFromPipelineByPropertyName=$True)]
        [VMware.Vim.ManagedObjectReference]
        $Network
    )
    Process
    {
        IF ($pscmdlet.parametersetname -eq 'name')
        {
            $net = Get-View -ViewType network |
                Where-Object {$_.name -like $Name}
        }
        Else
        {
            $net = Get-View -Id $Network
        }
        If ($net)
        {
            Foreach ($N in $net)
            {
                New-Object VMware.Vim.IpPoolAssociation `
                    -Property @{
                        Network=$N.MoRef
                        NetworkName=$N.Name
                    }
            }
        }
    }
}

Function Set-IPPool
{
    <#
    .SYNOPSIS
        Modify an existing IP Pool within vCenter
    .DESCRIPTION
        Modify an existing IP Pool within vCenter
    .NOTES
        Source:  Automating vSphere Administration
        Authors: Luc Dekens, Arnim van Lieshout, Jonathan Medd,
           Alan Renouf, Glenn Sizemore
    .PARAMETER Datacenter
        Datacenter to create the new IP Pool in.
    .PARAMETER Name
        Pool name.
    .PARAMETER Name
        New pool name. Must be unique. 
    .PARAMETER DnsDomain
        DNS Domain. For example, vmware.com. This can be an 
        empty string if no domain is configured. 
    .PARAMETER DNSSearchPath
        DNS Search Path. For example, eng.vmware.com;vmware.com
    .PARAMETER HostPrefix
        Prefix for hostnames.
    .PARAMETER HttpProxy
        The HTTP proxy to use on this network
    .PARAMETER NetworkAssociation
        The networks that are associated with this IP pool.
        
        Use the Get-Network function to get the objects this 
        parameter requires.
    .PARAMETER IPv4SubnetAddress
        Address of the subnet.
    .PARAMETER IPv4Netmask
        Netmask
    .PARAMETER IPv4Gateway
        Gateway. This can be an empty string
    .PARAMETER IPv4Range
        IP range. This is specified as a set of ranges 
        separated with commas. One range is given by a start 
        address, a hash (#), and the length of the range.
        For example:
        192.0.2.235#20 = IPv4 range 192.0.2.235-192.0.2.254
        192.0.2.0#24 = IPv4 range 192.0.2.1-192.0.2.254
    .PARAMETER IPv4DNS
        DNS servers 
    .PARAMETER IPv4DHCP
        Whether a DHCP server is available on this network.
    .PARAMETER IPv4IpPoolEnabled
        IP addresses can only be allocated from the range if 
        the IP pool is enabled. 
    .PARAMETER IPv6SubnetAddress
        Address of the subnet.
    .PARAMETER IPv6Netmask
        Netmask
    .PARAMETER IPv6Gateway
        Gateway. This can be an empty string
    .PARAMETER IPv6Range
        IP range. This is specified as a set of ranges 
        separated with commas. One range is given by a start
        address, a hash (#), and the length of the range.
        For example:
        2001::7334 # 20 = IPv6 range 2001::7334 - 2001::7347
    .PARAMETER IPv6DNS
        DNS servers 
    .PARAMETER IPv6DHCP
        Whether a DHCP server is available on this network.
    .PARAMETER IPv6IpPoolEnabled
        IP addresses can only be allocated from the range if 
        the IP pool is enabled.     
    .EXAMPLE
        
    #>
    [cmdletbinding()]
    Param(
        [Parameter(Mandatory=$True
        ,   ValueFromPipeline=$True
        ,   ValueFromPipelineByPropertyName=$True)]
        [VMware.VimAutomation.ViCore.Impl.V1.Inventory.DatacenterImpl]
        $Datacenter
    ,   [Parameter(Mandatory=$true
        ,   ValueFromPipelineByPropertyName=$True)]
        [String]
        $Name
    ,   [Parameter(ValueFromPipelineByPropertyName=$True)]
        [String]
        $NewName
    ,   [Parameter(ValueFromPipelineByPropertyName=$True)]
        [String]
        $DnsDomain
    ,   [Parameter(ValueFromPipelineByPropertyName=$True)]
        [String[]]
        $DNSSearchPath
    ,   [Parameter(ValueFromPipelineByPropertyName=$True)]
        [String]
        $HostPrefix
    ,   [Parameter(ValueFromPipelineByPropertyName=$True)]
        [String]
        $HttpProxy 
    ,   [Parameter(ValueFromPipeline=$True
        ,    ValueFromPipelineByPropertyName=$True)]
        [VMware.Vim.IpPoolAssociation[]]
        $NetworkAssociation
    ,   [Parameter(ValueFromPipelineByPropertyName=$True)]
        [String]
        $IPv4SubnetAddress
    ,   [Parameter(ValueFromPipelineByPropertyName=$True)]
        [String]
        $IPv4Netmask
    ,   [Parameter(ValueFromPipelineByPropertyName=$True)]
        [String]
        $IPv4Gateway
    ,   [Parameter(ValueFromPipelineByPropertyName=$True)]
        [String]
        $IPv4Range
    ,   [Parameter(ValueFromPipelineByPropertyName=$True)]
        [String[]]
        $IPv4DNS
    ,   [Parameter(ValueFromPipelineByPropertyName=$True)]
        [bool]
        $IPv4DHCP
    ,   [Parameter(ValueFromPipelineByPropertyName=$True)]
        [bool]
        $IPv4IpPoolEnabled
    ,   [Parameter(ValueFromPipelineByPropertyName=$True)]
        [String]
        $IPv6SubnetAddress
    ,   [Parameter(ValueFromPipelineByPropertyName=$True)]
        [String]
        $IPv6Netmask
    ,   [Parameter(ValueFromPipelineByPropertyName=$True)]
        [String]
        $IPv6Gateway
    ,   [Parameter(ValueFromPipelineByPropertyName=$True)]
        [String]
        $IPv6Range
    ,   [Parameter(ValueFromPipelineByPropertyName=$True)]
        [String[]]
        $IPv6DNS
    ,   [Parameter(ValueFromPipelineByPropertyName=$True)]
        [bool]
        $IPv6DHCP
    ,   [Parameter(ValueFromPipelineByPropertyName=$True)]
        [bool]
        $IPv6IpPoolEnabled
    )
    Process
    {
        $IPPoolManager = Get-View 'IpPoolManager-IpPoolManager'
        $pool = $IPPoolManager.QueryIpPools($Datacenter.ID)|
            Where-Object {$_.Name -eq $Name}
        Switch ($PSCmdlet.MyInvocation.BoundParameters.keys)
        {
            'NewName' {
                $pool.name = $Name
            }
            'IPv4SubnetAddress' {
               $pool.ipv4Config.subnetAddress=$IPv4SubnetAddress
            }
            'IPv4Netmask' {
                $pool.ipv4Config.netmask = $IPv4Netmask
            }
            'IPv4Gateway' {
                $pool.ipv4Config.gateway = $IPv4Gateway
            }
            'IPv4DNS' {
                $pool.ipv4Config.dns = $IPv4DNS
            }
            'IPv4DHCP' {
                $pool.ipv4Config.dhcpServerAvailable = $IPv4DHCP
            }
            'IPv4IpPoolEnabled' {
               $pool.ipv4Config.ipPoolEnabled=$IPv4IpPoolEnabled
            }
            'IPv4Range' {
                $pool.ipv4Config.range = $IPv4Range
            }
            'IPv6SubnetAddress' {
               $pool.ipv6Config.subnetAddress=$IPv6SubnetAddress
            }
            'IPv6Netmask' {
                $pool.ipv6Config.netmask = $IPv6Netmask
            }
            'IPv6Gateway' {
                $pool.ipv6Config.gateway = $IPv6Gateway
            }
            'IPv6DNS' {
                $pool.ipv6Config.dns = $IPv6DNS
            }
            'IPv6DHCP' {
                $pool.ipv6Config.dhcpServerAvailable = $IPv6DHCP
            }
            'IPv6IpPoolEnabled' {
               $pool.ipv6Config.ipPoolEnabled=$IPv6IpPoolEnabled
            }
            'IPv6Range' {
                $pool.ipv6Config.range = $IPv6Range
            }
            'DnsDomain' {
                $pool.dnsDomain = $DnsDomain
            }
            'DNSSearchPath' {
                $pool.dnsSearchPath = $DNSSearchPath
            }
            'HostPrefix' {
                $pool.hostPrefix = $HostPrefix
            }
            'HttpProxy' {
                $pool.httpProxy = $HttpProxy
            }
            'NetworkAssociation' {
                $pool.NetworkAssociation = $NetworkAssociation
            }
        }
        $IpPoolManager = Get-View 'IpPoolManager-IpPoolManager'
        $IpPoolManager.UpdateIpPool($DataCenter.id, $pool) |
            Out-Null
        if ($?)
        {
            Get-IPPool -Datacenter $DataCenter -Name $Name
        }
        
    }
}

Function Get-vAppIPAssignment
{
    <#
    .SYNOPSIS
        Get the IP assignment for the specified vApp.
    .DESCRIPTION
        Get the IP assignment for the specified vApp.
    .NOTES
        Source:  Automating vSphere Administration
        Authors: Luc Dekens, Arnim van Lieshout, Jonathan Medd,
           Alan Renouf, Glenn Sizemore
    .PARAMETER vApp
        vApp to rerieve the IP Assignment settings.
    .EXAMPLE
        Get-vApp | Get-vAppIPAssignment
    #>
    [cmdletbinding()]
    Param(
        [Parameter(ValueFromPipeline=$True)]
        [VMware.VimAutomation.ViCore.Impl.V1.Inventory.VAppImpl]
        $vApp
    )
    Process
    {
        $vapp.ExtensionData.VAppConfig.IpAssignment | %{
            New-Object PSObject -Property @{
                'vApp'=$vApp
                'IpProtocol'=$_.IpProtocol
                'IpAllocationPolicy'=$_.IpAllocationPolicy
                'SupportedIpAllocation'= `
                    $_.SupportedAllocationScheme
                'SupportedIpProtocol'=$_.SupportedIpProtocol
            }
        }
    }
}

Function Set-vAppIPAssignment
{
    <#
    .SYNOPSIS
        Set the IP assignment for the specified vApp.
    .DESCRIPTION
        Set the IP assignment for the specified vApp.  These 
        settings controle how the guest software gets 
        configured with IP addresses, including protocol type
        (IPv4 or IPv6) and the life-time of those IP addresses.
    .NOTES
        Source:  Automating vSphere Administration
        Authors: Luc Dekens, Arnim van Lieshout, Jonathan Medd,
           Alan Renouf, Glenn Sizemore
    .PARAMETER vApp
        vApp to modify the IP Assignment settings.
    .PARAMETER IpProtocol
        Specifies the chosen IP protocol for this deployment. 
        This must be one of the values in the 
        SupportedIpAllocation
    .PARAMETER IpAllocationPolicy
        Specifies how IP allocation should be managed by the VI
        platform. This is typically specified by the deployer. 
        Valid options are 'dhcpPolicy','transientPolicy', and
        'fixedPolicy'
    .PARAMETER SupportedIpAllocation
        Specifies the IP allocation schemes supported by the 
        guest software. When updating this field, an array of 
        the form "" will clear all settings. 
        
        Otherwise, the supplied value will overwrite the 
        current setting.
    .PARAMETER SupportedIpProtocol
        Specifies the IP protocols supported by the guest 
        software. When updating this field, an array in the 
        form "" will clear all settings. 
        
        Otherwise, the supplied value will overwrite the 
        current setting.
    .EXAMPLE
        
    #>
    [cmdletbinding(SupportsShouldProcess=$True)]
    Param(
        [Parameter(ValueFromPipeline=$True)]
        [VMware.VimAutomation.ViCore.Impl.V1.Inventory.VAppImpl]
        $vApp
    ,   [Parameter(ValueFromPipelineByPropertyName=$True)]
        [ValidateSet('IPv4','IPv6')]
        [string]
        $IpProtocol
    ,   [Parameter(ValueFromPipelineByPropertyName=$True)]
        [ValidateSet('dhcpPolicy','transientPolicy','fixedPolicy')]
        [string]
        $IpAllocationPolicy
    ,   [Parameter(ValueFromPipelineByPropertyName=$True)]
        [ValidateSet('ovfenv','dhcp')]
        [string[]]
        $SupportedIpAllocation
    ,   [Parameter(ValueFromPipelineByPropertyName=$True)]
        [ValidateSet('IPv4','IPv6')]
        [string[]]
        $SupportedIpProtocol
    )
    Process
    {
        $spec = New-Object VMware.Vim.VAppConfigSpec
        $spec.ipAssignment = `
            $vApp.ExtensionData.VAppConfig.IpAssignment
        $msg = "Modifing $($vApp.Name)"
        Switch ($PSCmdlet.MyInvocation.BoundParameters.keys)
        {
            'IpProtocol'
            {
                $msg = "{0} IP protocol:{1}" -f $msg,
                    $IpProtocol
                $spec.ipAssignment.ipProtocol = `
                    switch ($IpProtocol)
                    {
                        'ipv4' {'IPv4'}
                        'ipv6' {'IPv6'}
                    }
            }
            'IpAllocationPolicy'
            {
                $msg = "{0} IP allocation policy:{1}" -f $msg,
                    $IpAllocationPolicy
                $spec.ipAssignment.IpAllocationPolicy = `
			switch ($IpAllocationPolicy)
                        {
                            'dhcpPolicy' {'dhcpPolicy'}
                            'transientPolicy' {'transientPolicy'}
                            'fixedPolicy' {'fixedPolicy'}
                        }                    
            }
            'SupportedIpAllocation'
            {
                $msg="{0} supported allocation policy:{1}" -f `
                    $msg,$($SupportedIpAllocation -join ',')
                $spec.ipAssignment.SupportedAllocationScheme = `
                        $SupportedIpAllocation | %{$_.TOLOWER()}
            }
            'SupportedIpProtocol'
            {
                $msg = "{0} supported IP protocol:{1}" -f $msg,
                    $($SupportedIpProtocol -join ',')
                $spec.ipAssignment.supportedIpProtocol = `
                    switch ($SupportedIpProtocol)
                    {
                        'ipv4' {'IPv4'}
                        'ipv6' {'IPv6'}
                    }
            }
        }
        if ($PSCmdlet.ShouldProcess($vApp.Name,$msg))
        {
            $vApp.ExtensionData.UpdateVAppConfig($spec)
            if ($?)
            {
                Get-vAppIPAssignment -vApp $vApp
            }
        }
    }
}

Function Get-vAppProductInfo
{
    <#
    .SYNOPSIS
        Get the vApp Product Information
    .DESCRIPTION
        Get the vApp Product Information
    .NOTES
        Source:  Automating vSphere Administration
        Authors: Luc Dekens, Arnim van Lieshout, Jonathan Medd,
           Alan Renouf, Glenn Sizemore
    .PARAMETER vApp
        vApp to retrieve the Product Information for.
    .EXAMPLE
        Get-VApp | Get-vAppProductInfo
    #>
    [cmdletbinding()]
    Param(
        [Parameter(ValueFromPipeline=$True
        ,   ValueFromPipelineByPropertyName=$True)]
        [VMware.VimAutomation.ViCore.Impl.V1.Inventory.VAppImpl]
        $vApp
    )
    Process
    {
        $vApp.ExtensionData.VAppConfig.Product | 
            Select-Object -Property @{
                    Name='vApp'
                    Expression={$vApp}
                },'Name','Vendor','Version','FullVersion',
                'VendorUrl','ProductUrl','AppUrl'
    }
}

Function Set-vAppProductInfo
{
    <#
    .SYNOPSIS
        Set the vApp Product Information
    .DESCRIPTION
        Set the vApp Product Information
        
        Information that describes what product a vApp 
        contains, e.g., what software that is installed in 
        the contained virtual machines.
    .NOTES
        Source:  Automating vSphere Administration
        Authors: Luc Dekens, Arnim van Lieshout, Jonathan Medd,
           Alan Renouf, Glenn Sizemore
    .PARAMETER vApp
        vApp to set the product information for.
    .PARAMETER Name
        Name of the Product
    .PARAMETER Vendor
        Vendor of the product. 
    .PARAMETER Version
        Short version of the product , e.g., 1.0. 
    .PARAMETER FullVersion
        Full-version of the product, e.g., 1.0-build 12323. 
    .PARAMETER VendorUrl
        URL to vendor homepage. 
    .PARAMETER ProductUrl
        URL to product homepage. 
    .PARAMETER AppUrl
        URL to entry-point for application. This is often 
        specified using a macro, e.g., http://${app.ip}/, 
        where app.ip is a defined property on the virtual 
        machine or vApp container. 
    .EXAMPLE
        Get-VApp App01| Set-vAppProductInfo `
            -Vendor 'VMware' -Version '4' -FullVersion '4.1'
    #>
    [cmdletbinding()]
    Param(
        [Parameter(ValueFromPipeline=$True
        ,   ValueFromPipelineByPropertyName=$True)]
        [VMware.VimAutomation.ViCore.Impl.V1.Inventory.VAppImpl]
        $vApp
    ,   [Parameter(ValueFromPipelineByPropertyName=$True)]
        [string]
        $Name
    ,   [Parameter(ValueFromPipelineByPropertyName=$True)]
        [string]
        $Vendor
    ,   [Parameter(ValueFromPipelineByPropertyName=$True)]
        [string]
        $Version
    ,   [Parameter(ValueFromPipelineByPropertyName=$True)]
        [string]
        $FullVersion
    ,   [Parameter(ValueFromPipelineByPropertyName=$True)]
        [string]
        $VendorUrl
    ,   [Parameter(ValueFromPipelineByPropertyName=$True)]
        [string]
        $ProductUrl
    ,   [Parameter(ValueFromPipelineByPropertyName=$True)]
        [string]
        $AppUrl
    )
    Process
    {
        $spec = New-Object VMware.Vim.VAppConfigSpec
        $spec.product = `
            New-Object VMware.Vim.VAppProductSpec[] (1)
        $spec.product[0]= New-Object VMware.Vim.VAppProductSpec
        $spec.product[0].operation = "edit"
        $spec.product[0].info = `
            New-Object VMware.Vim.VAppProductInfo
        $spec.product[0].info.key = `
            $vApp.ExtensionData.VAppConfig.Property| 
            Select -ExpandProperty Key -First 1
        $msg = "Modifing Advanced Properties "
        Switch ($PSCmdlet.MyInvocation.BoundParameters.keys)
        {
            'Name'
            {
                $spec.product[0].info.Name = $name
                $msg = "{0} Name:{1}" -f $msg,$Name
            }
            'Vendor'
            {
                
                $spec.product[0].info.Vendor = $Vendor
                $msg = "{0} Vendor:{1}" -f $msg,$Vendor
            }
            'Version'
            {
                $spec.product[0].info.Version = $Version
                $msg = "{0} Version:{1}" -f $msg,$Version
            }
            'FullVersion'
            {
                $spec.product[0].info.FullVersion = $Fullversion
                $msg = "{0} Full version:{1}" -f $msg,
                    $Fullversion
            }
            'VendorUrl'
            {
                $spec.product[0].info.VendorUrl = $vendorURL
                $msg = "{0} vendor URL:{1}" -f $msg,$vendorURL
            }
            'ProductUrl'
            {
                $spec.product[0].info.ProductUrl = $productUrl
                $msg = "{0} product Url:{1}" -f $msg,
                    $productUrl
            }
            'AppUrl'
            {
                $spec.product[0].info.AppUrl = $AppUrl
                $msg = "{0} App Url:{1}" -f $msg,$AppUrl
            }
        }
        
        if ($PSCmdlet.ShouldProcess($vApp.Name,$msg))
        {
            $vApp.ExtensionData.UpdateVAppConfig($spec)
            if ($?)
            {
                Get-vAppProductInfo -vApp $vApp
            }
        }
    }
}


function Backup-MsSqlDatabase {
<#
.SYNOPSIS
  Backup a Microsoft SQL database
.DESCRIPTION
  This function backs up a Microsoft SQL database using
  SQL Server Management Objects (SMO)
.NOTES
  Source:  Automating vSphere Administration
  Authors: Luc Dekens, Arnim van Lieshout, Jonathan Medd,
           Alan Renouf, Glenn Sizemore
.PARAMETER instance
  The SQL Server instance to backup. e.g. VC01\SQLEXP_VIM
.PARAMETER database
  An array of databases to backup.
  If omitted all databases on the server instance are backed up
.PARAMETER backupType
  The backup type. Valid options are Full,Diff,Log
.PARAMETER path
  The path where the backup files will be written.
  If omitted the default server backup location will be used
.EXAMPLE
  PS> Backup-MsSqlDatabase -Instance vc01\sqlexp_vim -Database vim_vcdb -Backuptype full -Path c:\sqlbackup
#>

  Param (
    [parameter(mandatory = $true,
    HelpMessage = "Enter an MSSQL instance")]
      [String]$Instance,
      [string[]]$Database,
    [parameter(mandatory = $true,
    HelpMessage = "Enter the backup type (Full,Diff,Log)")]
      [string]$BackupType ,
    [parameter(mandatory = $true,
    HelpMessage = "Enter the backup path")]
      [string]$Path)

# Load SQLServer SMO assemblies
  [System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo") | Out-Null
# For SQL Server 2008, you also need to load
# Microsoft.SqlServer.SmoExtended
  [System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoExtended") | Out-Null

# Create backup directory    
  if (-not (Test-Path $path)){
    New-Item $path -type directory | out-null
  }

# Create objects  
  $serverObject = New-Object "Microsoft.SqlServer.Management.Smo.Server" "$instance" 

  $timeStamp = Get-Date -format yyyyMMddHHmmss
  if (-not $database) {
    foreach ($db in $serverObject.databases) {
# Exclude tempdb
      if ($db.Name -ne "tempdb") {$database += $db.name}
    }
  }
    
# process databases
  foreach ($db in $database) {
    $backupObject = New-Object "Microsoft.SqlServer.Management.Smo.Backup"
# evaluate backup type
    Switch ($backupType) {
      "Full" {
        $backupObject.Action = 'Database'
        $backupObject.Incremental = $false
        $extension=".BAK"
        $message="Full Backup of "
      }
      "Diff" { 
        $backupObject.Action = 'Database'
        $backupObject.Incremental = $true
        $extension=".DIFF" 
        $message="Differential Backup of "
      }
      "Log" {
        $backupObject.Action = 'Log'
        $extension=".LOG"
        $message="Transactional Log Backup of "
      }
      default {
        Write-Host -foregroundcolor Red 'Invalid Backup Type specified!'
        return
      }
    }

    $backupObject.BackupSetName = $db + " Backup"
    $backupObject.BackupSetDescription = $message + $db
    $backupObject.Devices.AddDevice($path + "\" + $db + "_" + $timeStamp + $extension, "File") 
    $backupObject.Database = $db
    $backupObject.SqlBackup($serverObject)

    Write-Host $message$db finished
  }
}

function Backup-VcConfig {
<#
.SYNOPSIS
  Backup a vCenter Server's configuration files
.DESCRIPTION
  This function backs up the configuration data from
  a vCenter Server.
.NOTES
  Source:  Automating vSphere Administration
  Authors: Luc Dekens, Arnim van Lieshout, Jonathan Medd,
           Alan Renouf, Glenn Sizemore
.PARAMETER vCenter
  The vCenter Servername by which it will be reachable
  over the network.
.PARAMETER destination
  The destination path where the backup files will be stored
.PARAMETER vi3license
  Optional parameter to specify to backup the VI3 license file
  if you happen to still have ESX 3.x hosts in your environment
.PARAMETER ssl
  Optional parameter to specify to backup the ssl certificate
.PARAMETER config
  Optional parameter to specify to backup the vCenter
  config file
.EXAMPLE
  PS> Backup-VcConfig -vCenter VC01 -destination c:\temp
#>
  Param (
    [parameter(mandatory = $true,
    HelpMessage = "Enter your vCenter Server")]
      [String]$vCenter,
    [parameter(mandatory = $true,
    HelpMessage = "Enter a destination path")]
      [string]$destination,
    [switch]$vi3License, [switch]$ssl, [switch]$config)

#  Define default paths
#  Modify these paths to match your installation.
#
#  Default paths for Windows2003
#  $sslPath="\\$vCenter\C$\Documents and Settings\All Users\Application Data\VMware\VMware VirtualCenter\SSL"
#  $configPath="\\$vCenter\C$\Documents and Settings\All Users\Application Data\VMware\VMware VirtualCenter\vpxd.cfg"
#
#  Default paths for Windows2008
#  $sslPath="\\$vCenter\C$\ProgramData\VMware\VMware VirtualCenter\SSL"
#  $configPath="\\$vCenter\C$\ProgramData\VMware\VMware VirtualCenter\vpxd.cfg"

  $sslPath="\\$vCenter\C$\ProgramData\VMware\VMware VirtualCenter\SSL"
  $configPath="\\$vCenter\C$\ProgramData\VMware\VMware VirtualCenter\vpxd.cfg"
  $licensePath="\\$vCenter\C$\Program Files (x86)\VMware\VMware License Server\Licenses"

  $sourceFiles=@()
  if ($vi3License) {$sourceFiles += $licensePath}
  if ($ssl) {$sourceFiles += $sslPath}
  if ($config) {$sourceFiles += $configPath}
  if ($vi3License,$ssl,$config -notcontains $true) {
    $sourceFiles = $SSLPath,$configPath
  }

# Create backup directory
  if (-not (Test-Path $destination)){
    New-Item $destination -type directory |  out-null
  }

# Create backup
  Copy-Item -Path $sourceFiles -Destination $destination -Recurse -Force
}

function Restore-MsSqlDatabase {
<#
.SYNOPSIS
  Restore a Microsoft SQL database
.DESCRIPTION
  This function restores a Microsoft SQL database using
  SQL Server Management Objects (SMO)
.NOTES
  Source:  Automating vSphere Administration
  Authors: Luc Dekens, Arnim van Lieshout, Jonathan Medd,
           Alan Renouf, Glenn Sizemore
.PARAMETER instance
  The SQL Server instance to restore the database
  to. e.g. VC01\SQLEXP_VIM
.PARAMETER backupFile
  The backup file to restore
.PARAMETER NoRecovery
  Optional switch to prevent transaction recovery.
.EXAMPLE
  PS> Restore-MsSqlDatabase -instance vc01\sqlexp_vim -backupFile c:\sqlbackup\VIM_VCDB_20100729233423.BAK
#>

  Param (
    [parameter(mandatory = $true,
    HelpMessage = "Enter an MSSQL instance")]
      [String]$instance,
    [parameter(mandatory = $true,
    HelpMessage = "Enter the backup file")]
      [string]$backupFile,
    [switch]$NoRecovery)

# Load SQLServer SMO assemblies
  [System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo") | Out-Null
# For SQL Server 2008, you'll also need to load
# Microsoft.SqlServer.SmoExtended
  [System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoExtended") | Out-Null

# Test backupFile    
  if (-not (Test-Path $backupfile)){
    Write-Host backup file: $backupFile not found!
    Return
  }

# Create objects  
  $serverObject = `
      New-Object "Microsoft.SqlServer.Management.Smo.Server" "$instance" 
  $restoreObject = `
      New-Object "Microsoft.SqlServer.Management.Smo.Restore"
  
  if ($NoRecovery) {
    $restoreObject.NoRecovery = $true
  }
  else {
    $restoreObject.NoRecovery = $false
  }
  $restoreObject.ReplaceDatabase = $true
  $restoreObject.Action = "Database"
  $restoreObject.Devices.AddDevice($backupFile, "File")
  
#determine database to restore
  $restoreInfo = $restoreObject.ReadBackupHeader($serverObject)
  $restoreObject.Database = $restoreInfo.Rows[0]["DatabaseName"]

#restore database  
  $restoreObject.SqlRestore($serverObject)
  Write-Host Restore of $restoreObject.Database finished
}

Function Connect-VMHost {
<#
.SYNOPSIS
  Connect a disconnected ESX host
.DESCRIPTION
  This function (re)connects a disconnected ESX host.
.NOTES
  Source:  Automating vSphere Administration
  Authors: Luc Dekens, Arnim van Lieshout, Jonathan Medd,
           Alan Renouf, Glenn Sizemore
.PARAMETER vmHost
  The VMHost object to connect
.PARAMETER credential
  A PSCredential object used to authenticate the VMHost server
.PARAMETER user
  The user account used to authenticate the VMHost server
.PARAMETER password
  The password for the account specified by the -User parameter
.PARAMETER reconnect
  An optional switch parameter to force a disconnect first
.EXAMPLE
  PS> Connect-VMHost -VMHost MyESX -User root -Password password
.EXAMPLE
  PS> Get-VMHost myESX | Connect-VMHost -User root -Password password -Reconnect
.EXAMPLE
  PS> Get-VMHost myESX | Connect-VMHost -Credential (Get-Credential)
#>

  Param (
    [Parameter(ValueFromPipeline = $true, Position = 0,
    Mandatory = $true,
    HelpMessage = "Enter an ESX(i) host entity")] 
      [VMware.VimAutomation.ViCore.Impl.V1.Inventory.VMHostImpl]$vmHost,
    [Parameter(Mandatory = $true, ParameterSetName = "cred",
    HelpMessage = "Enter a PSCredential object")]
      [System.Management.Automation.PSCredential]$credential,
    [Parameter(ParameterSetName = "user")]
    [ValidateNotNullOrEmpty()]
      [string]$user = "root",
    [Parameter(Mandatory = $true, ParameterSetName = "user",
    HelpMessage = "Enter the root account password")]
      [string]$password,
    [switch]$reconnect)
    
  Process {
    if($vmHost) {
      $vmHostView = $vmHost | Get-View
    }
    else {
      $vmHostView = $_ | Get-View
    }

# Create a new HostConnectSpec object
    $objHostConnectSpec = New-Object VMware.Vim.HostConnectSpec
    if ($credential) {
      $objHostConnectSpec.userName = 
        $credential.GetNetworkCredential().UserName
      $objHostConnectSpec.password = 
        $credential.GetNetworkCredential().Password
    }
    else {
      $objHostConnectSpec.userName = $user
      $objHostConnectSpec.password = $password
    }

# if Reconnect switch is specified disconnect host first
    if ($reconnect) {
      Write-Host "Disconnecting $($vmHost.Name) " -NoNewline
      $taskMoRef = $vmHostView.DisconnectHost_Task()
      $task = Get-View $taskMoRef
      while ("running","queued" -contains $task.Info.State){
        Write-Host "." -NoNewline
        Sleep 2
        $task.UpdateViewData("Info.State")
      }
      Write-Host "Done"
      $task.UpdateViewData("Info.Result")
      $task.Info.State
    }

# Connect host
    Write-Host "Connecting $($vmHost.Name) " -NoNewline
    $taskMoRef = $vmHostView.ReconnectHost_Task($objHostConnectSpec)
    $task = Get-View $taskMoRef
    while ("running","queued" -contains $task.Info.State){
      Write-Host "." -NoNewline
      Sleep 2
      $task.UpdateViewData("Info.State")
    }
    Write-Host "Done"
    $task.UpdateViewData("Info.Result")
    $task.Info.State
  }
}

function Get-FolderStructure {
<#
.SYNOPSIS
  Retrieve folder structure
.DESCRIPTION
  This function retrieves the folder structure beneath
  the given container
.NOTES
  Source:  Automating vSphere Administration
  Authors: Luc Dekens, Arnim van Lieshout, Jonathan Medd,
           Alan Renouf, Glenn Sizemore
.EXAMPLE
  PS> Get-Datacenter DC01 | Get-FolderStructure
#>

  process {
    $folder = "" | select Name,Children
    $folder.Name = $_.Name
    $folder.Children = @($_ | Get-Folder -NoRecursion | Get-FolderStructure)
    $folder
  }
}

function Get-VIPath {
<#
.SYNOPSIS
  Retrieve the full path of an inventory object
.DESCRIPTION
  This function retrieves the full path of the given
  inventory object
.NOTES
  Source:  Automating vSphere Administration
  Authors: Luc Dekens, Arnim van Lieshout, Jonathan Medd,
           Alan Renouf, Glenn Sizemore
.PARAMETER inputObject
  The inventory object to retrieve the full path from
.PARAMETER childPath
  Optional parameter used by the function when calling itself
  recursively
.EXAMPLE
  PS> Get-Datacenter DC01 | Get-VIPath
#>
  
  param (
    [parameter(valuefrompipeline = $true, mandatory = $true,
    HelpMessage = "Enter an inventory object entity")]
      $InputObject,
    [parameter(mandatory = $false,
    HelpMessage = "Enter a path object")] $ChildPath)

  process {
    if($inputObject.parent) {
      $parent = Get-View $inputObject.parent
      if ($parent.gettype().name -eq "Datacenter") {
        $childPath
      } else {
        $path = "" | select Name,Child
        $path.Name = $parent.Name
        $path.Child = $childPath
        $parent | Get-VIPath -Child $path
      }
    }
    else {
      $childPath
    }
  }
}

filter New-FolderStructure {
  param($parent)
  if (-not($folder = Get-Folder $_.name -Location $parent -ErrorAction:SilentlyContinue)) {
    $folder = New-Folder $_.name -Location $parent
  }
  $_.children | New-FolderStructure($folder)
}

filter Get-VILocation {
  param($parent)
  if ($_.child) {
    $_.child | Get-VILocation(Get-Folder -Location $parent $_.Name)
  } else {
    Get-Folder -Location $parent $_.Name
  }
}

filter Escape-MetaCharacters {
  ForEach($MetaChar in '^','$','{','}','[',']','(',')','.','*','+','?','|','<','>','-','&') {
    $_=$_.replace($MetaChar,"\$($Metachar)")
  }
  $_
}

function Register-VMX {
<#
.SYNOPSIS
  Find and register virtual machines
.DESCRIPTION
  This function searches datastores for vmx or vmtx files and
  then registers the virtual machines. You can search on one or
  more datastores, a host, a cluster or a datacenter
.NOTES
  Source:  Automating vSphere Administration
  Authors: Luc Dekens, Arnim van Lieshout, Jonathan Medd,
           Alan Renouf, Glenn Sizemore
.PARAMETER entityNames
  An array of entity names. Only clusters, datacenters or
  ESX hosts are allowed.
  Wildcards are supported. (mutually exclusive with -dsNames)
.PARAMETER dsNames
  An array of datastore names. Wildcards are supported.
  (mutually exclusive with -entityNames)
.PARAMETER ignore
  An array of folder names that shouldn't be checked.
  No wildcards allowed!
.PARAMETER template
  when set, the function searches for templates (.vmtx)
  otherwise it will search for guests (.vmx)
.PARAMETER checkNFS
  When set, the NFS datastores are included in the search
.PARAMETER whatif
  When set, the function will only list output to the console
  and not register the found vmx files
.EXAMPLE
  PS> Register-VMX -entityName "MyDatacenter"
.EXAMPLE
  PS> Register-VMX -dsNames "datastore1","datastore2" -template:$true
.EXAMPLE
  PS> Register-VMX -dsNames "datastore3" -ignore "SomeFolder" -checkNFS:$true 
.EXAMPLE
  PS> Register-VMX -entityName "MyCluster" -whatif:$true
#>
  param(
    [Parameter(Mandatory = $true,
    ParameterSetName = "entityNames",
    HelpMessage = "Enter cluster, datacenter or ESX host name")]
      [string[]]$entityNames,
    [Parameter(Mandatory = $true, ParameterSetName = "dsNames",
    HelpMessage = "Enter one or more datastore names")]
      [String[]]$dsNames,
    [switch]$template, [string[]]$ignore,
    [switch]$checkNFS, [switch]$whatif)

  if($dsNames) {
    $datastores = Get-Datastore -Name $dsNames | where {$_.Type -eq "VMFS" -or $checkNFS} | Select -Unique
  }
  else {
    $datastores=@()
    foreach($entity in Get-Inventory -Name $entityNames) {
      switch(($entity | Get-View).GetType().Name){
        "ClusterComputeResource" {
          $datastores += Get-Cluster -Name $entity | Get-VMHost | Get-Datastore | where {$_.Type -eq "VMFS" -or $checkNFS} | Select -Unique
        }
        "Datacenter" {
          $datastores += Get-Datacenter -Name $entity | Get-Datastore | where {$_.Type -eq "VMFS" -or $checkNFS} | Select -Unique
        }
        "HostSystem" {
          $datastores += Get-VMHost -Name $entity | Get-Datastore | where {$_.Type -eq "VMFS" -or $checkNFS} | Select -Unique
        }
        Default {
          Write-Host -foregroundcolor Red "Invalid entity type [$_] specified!"
          Return
        }
      }
    }
  }
  if($template){
    $pattern = "*.vmtx"
  }
  else {
    $pattern = "*.vmx"
  }
  if ($datastores) {
    $datastores = $datastores | Select -Unique | Sort-Object -Property Name
    foreach($datastore in $datastores){
      Write-Host "Checking " -NoNewline
      Write-Host -ForegroundColor red -BackgroundColor yellow $datastore.Name
      $dsView = $datastore | Get-View
      $dsBrowser = Get-View $dsView.Browser
      $dc = Get-View $dsView.Parent
      while($dc.MoRef.Type -ne "Datacenter"){
        $dc = Get-View $dc.Parent
      }
      $targetFolder = Get-View $dc.VmFolder
      $esxHost = Get-View ($dsView.host | Get-Random).key
      $pool = Get-View (Get-View $esxHost.Parent).ResourcePool
  
      $registeredVMs = @()
      foreach($vm in $dsView.Vm){
        $vmView = Get-View $vm
        $registeredVMs += $vmView.Config.Files.VmPathName
      }
      $datastorepath = "[" + $dsView.Name + "]"
  
      $searchspec = New-Object VMware.Vim.HostDatastoreBrowserSearchSpec
      $searchspec.MatchPattern = $pattern
  
      $taskMoRef = $dsBrowser.SearchDatastoreSubFolders_Task($datastorePath, $searchSpec)
  
      $task = Get-View $taskMoRef
      while ("running","queued" -contains $task.Info.State){
        $task.UpdateViewData("Info.State")
      }
      $task.UpdateViewData("Info.Result")
      foreach ($folder in $task.Info.Result){
        if($folder.file -ne $null){
          if($folder.FolderPath[-1] -ne "/"){
            $folder.FolderPath += "/"
          }
          $vmx = $folder.FolderPath + $folder.File[0].Path
          $skip = $false
          if($ignore){
            $folder.FolderPath.Split("]")[1].Trim(" /").Split("/") | %{$skip = $skip -or ($ignore -contains $_)}
          }
          if($skip) {
            Write-Host -ForegroundColor red "`t" $vmx "Ignored!"
          }
          else {
            $exists = $false
            foreach($registeredVM in $registeredVMs){
              if($vmx -eq $registeredVM){
                $exists = $true
              }
            }
            if ($exists){
              Write-Host -ForegroundColor red "`t" $vmx "Skipped! Already registered"
            }
            else {
              if($template){
                $params = @($vmx,$null,$true,$null,$esxHost.MoRef)
              }
              else{
                $params = @($vmx,$null,$false,$pool.MoRef,$null)
              }
              if(!$whatif){
                $taskMoRef = $targetFolder.GetType().GetMethod("RegisterVM_Task").Invoke($targetFolder, $params)
                Write-Host -ForegroundColor green "`t" $vmx "registered"
              }
              else{
                Write-Host -ForegroundColor green "`t" $vmx "registered" -NoNewline
                Write-Host -ForegroundColor blue -BackgroundColor white " ==> What If"
              }
            }
          }
        }
      }
      Write-Host "Done"
    }
  }
}
function Get-VMGuestDiskUsage {
<#
.SYNOPSIS
  Gets a vm's guest OS disk usage information
.DESCRIPTION
  This function creates a report with disk usage information
  of the vm's guest OS
.NOTES
  Source:  Automating vSphere Administration
  Authors: Luc Dekens, Arnim van Lieshout, Jonathan Medd,
           Alan Renouf, Glenn Sizemore
.PARAMETER VM
  The VM object to create a report on
.EXAMPLE
  PS> Get-VMGuestDiskUsage -VM (Get-VM WIN*)
.EXAMPLE
  PS> Get-VM | Get-VMGuestDiskUsage
#>

  param(
    [parameter(valuefrompipeline = $true, mandatory = $true,
      HelpMessage = "Enter a vm entity")]
    [VMware.VimAutomation.ViCore.Impl.V1.Inventory.VirtualMachineImpl]$VM)

  process {
#Hide errors that appear if VMware Tools is not installed or VM is PoweredOff
    $ErrorActionPreference = "SilentlyContinue"

    foreach ($disk in $VM.Guest.disks) {
      $objDisk = New-Object System.Object
      $objDisk | Add-Member -MemberType NoteProperty -Name VM -Value $VM.Name 
      $objDisk | Add-Member -MemberType NoteProperty -Name Volume -Value $disk.Path
      $objDisk | Add-Member -MemberType NoteProperty -Name CapacityMB -Value ([math]::Round($disk.Capacity / 1MB))
      $objDisk | Add-Member -MemberType NoteProperty -Name FreeSpaceMB -Value ([math]::Round($disk.FreeSpace/1MB))
      $objDisk | Add-Member -MemberType NoteProperty -Name Usage% -Value ("{0:p2}" -f (($disk.Capacity - $disk.FreeSpace ) / $disk.Capacity))
      $objDisk
    }
  }
}

function Get-VMHostPciDevice {
<#
.SYNOPSIS
  Returns the ESX(i) host's PCI Devices
.DESCRIPTION
  This function returns the ESX(i) host's PCI devices and the associated 
  ESX devices. Pci device information is downloaded from http://pci-ids.ucw.cz/
.NOTES
  Source:  Automating vSphere Administration
  Authors: Luc Dekens, Arnim van Lieshout, Jonathan Medd,
           Alan Renouf, Glenn Sizemore
.PARAMETER VMHost
  The ESX(i) host entity for which the PCI devices should be returned
.PARAMETER forceDownload
  Switch parameter to force a download of the pci information
.EXAMPLE
  PS> Get-VMHostPciDevice -VMHost (Get-VMHost "esx001")
.EXAMPLE
  PS> Get-VMHost "esx001" | Get-VMHostPciDevice
#>

  Param (
  [parameter(valuefrompipeline = $true, mandatory = $true,
    HelpMessage = "Enter an ESX(i) host entity")]
  [VMware.VimAutomation.ViCore.Impl.V1.Inventory.VMHostImpl]$VMHost,
  [Switch]$forceDownload)

  Begin {
    $urlPci = "http://pci-ids.ucw.cz/v2.2/pci.ids"
    $filename = "pci.ids"
    $pciDevices= @{}
# Download file if not present or if forced download
    if(!(Test-Path $filename) -or $forceDownload){
      $web = New-Object net.WebClient
      $web.downloadfile($urlPCI,$filename)
    }
# Read file into hash tab
    Get-Content $filename | where {$_.Length -ne 0 -and $_[0] -ne "#"} | %{
      if($_[0] -eq "`t"){
        if($_[1] -eq "`t"){
          $subdeviceId = $_.Substring(2,4)
          if(!$pciDevices[$vendorId].deviceTab.ContainsKey($subdeviceId)){
            $pciDevices[$vendorId].deviceTab[$subdeviceId] = 
              $_.Substring(6).TrimStart(" ")
          }
        }
        else{
          $deviceId = "0x" + $_.Substring(1,4)
          if(!$pciDevices[$vendorId].deviceTab.ContainsKey($deviceId)){
            $pciDevices[$vendorId].deviceTab[$deviceId] = 
              $_.Substring(5).TrimStart(" ")
          }
        }
      }
      else{
        $vendorId = "0x" + $_.Substring(0,4)
        if(!$pciDevices.ContainsKey($vendorId)){
          $pciDevices[$vendorId] = New-Object PSObject -ArgumentList @{
            Vendor = $_.Substring(4).TrimStart(" ")
            deviceTab = @{}
          }
        }
      }
    }
# Create PCI class array
    $PciClass = @("Unclassified device","Mass storage controller",
      "Network controller","Display controller","Multimedia controller",
      "Memory controller","Bridge","Communication controller",
      "Generic system peripheral","Input device controller",
      "Docking station","Processor","Serial bus controller",
      "Wireless controller","Intelligent controller",
      "Satellite communications controller"," Encryption controller",
      "Signal processing controller")
  }

  Process {
# Get the host's PCI Devices
    $hostDevices = @()
    foreach ($dev in $VMHost.ExtensionData.Hardware.PciDevice) {
      $strVendorId = "0x" + "{0}" -f 
        [Convert]::ToString($dev.VendorId,16).ToUpper().PadLeft(4, '0')
      $strDeviceId = "0x" + "{0}" -f 
        [Convert]::ToString($dev.DeviceId,16).ToUpper().PadLeft(4, '0')
      $objDevice = "" | 
        Select Pci, ClassName, VendorName, DeviceName, EsxDeviceName
      $objDevice.Pci = $dev.Id
      $objDevice.ClassName = $PciClass[[int]($dev.ClassId/256)]
      if($pciDevices.ContainsKey($strVendorId)){
        $objDevice.VendorName = $pciDevices[$strVendorId].Vendor
      }
      else{
        $objDevice.VendorName = $strVendorId
      }
      if($pciDevices[$strVendorId].deviceTab.ContainsKey($strDeviceId)){
        $objDevice.DeviceName = 
          $pciDevices[$strVendorId].deviceTab[$strDeviceId]
      }
      else{
        $objDevice.DeviceName = $strDeviceId
      }
      $hostDevices += $objDevice
    }
  
# Find associated ESX storage devices
    foreach ($hba in $_.ExtensionData.Config.StorageDevice.HostBusAdapter) {
      $hostDevices | ? {$_.Pci -match $hba.Pci} | % {
        $_.EsxDeviceName = "["+$hba.device+"]"}
    }

# Find associated ESX network devices
    foreach ($nic in $_.ExtensionData.Config.Network.Pnic) {
      $hostDevices | ? {$_.Pci -match $nic.Pci} | % {
        $_.EsxDeviceName = "["+$nic.device+"]"}
    }
    $hostDevices
  }
}

function Get-ClusterSummary {
<#
.SYNOPSIS
  Gets summary information from the cluster
.DESCRIPTION
  This function creates a report with summary information of the
  cluster
.NOTES
  Source:  Automating vSphere Administration
  Authors: Luc Dekens, Arnim van Lieshout, Jonathan Medd,
           Alan Renouf, Glenn Sizemore
.PARAMETER Cluster
  The cluster object to create a report on
.EXAMPLE
  PS> Get-ClusterSummary -Cluster (Get-Cluster CL01)
.EXAMPLE
  PS> Get-Cluster | Get-ClusterSummary
#>

  param(
    [parameter(valuefrompipeline = $true, mandatory = $true,
      HelpMessage = "Enter a cluster entity")]
    [VMware.VimAutomation.ViCore.Impl.V1.Inventory.ClusterImpl]$cluster)

  process {
    $objCluster = "" | Select ClusterName, NumHost, NumVM, NumDatastore, NumNetwork, AssignedCpu, NumCores, `
        vCpuPerCore, TotalCpuGHz, TotalMemGB, AssignedMemGB, MemUsagePct
    $vm = @($cluster | Get-VM)
    $objCluster.ClusterName = $cluster.Name
    $objCluster.NumHost = $cluster.ExtensionData.Summary.NumHosts
    $objCluster.NumVM = $vm.Count
    $objCluster.NumDatastore = $cluster.ExtensionData.Datastore.Count
    $objCluster.NumNetwork = $cluster.ExtensionData.Network.Count
    $objCluster.AssignedCpu = ($vm | Where {$_.PowerState -eq "PoweredOn"} | Measure-Object -Property NumCpu -Sum).Sum
    $objCluster.NumCores = $cluster.ExtensionData.Summary.NumCpuCores
    $objCluster.vCpuPerCore = "{0:n2}" -f ($objCluster.AssignedCpu / $objCluster.NumCores)
    $objCluster.TotalCpuGhz = "{0:n2}" -f ($cluster.ExtensionData.Summary.TotalCpu / 1000)
    $objCluster.TotalMemGB = "{0:n2}" -f ($cluster.ExtensionData.Summary.TotalMemory / 1GB)
    $objCluster.AssignedMemGB = "{0:n2}" -f (($vm | Where {$_.PowerState -eq "PoweredOn"} | Measure-Object -Property MemoryMB -Sum).Sum / 1024)
    $objCluster.MemUsagePct = "{0:p2}" -f ($objCluster.AssignedMemGB / $objCluster.TotalMemGB)
    $objCluster
  }
}

function Get-MissingPortgroups {
<#
.SYNOPSIS
  Gets the inconsistent virtual portgroups in a cluster
.DESCRIPTION
  This function creates a report of the inconsistent portgroups
  in a cluster. It reports which portgroups are missing on which
  host.
.NOTES
  Source:  Automating vSphere Administration
  Authors: Luc Dekens, Arnim van Lieshout, Jonathan Medd,
           Alan Renouf, Glenn Sizemore
.PARAMETER Cluster
  The cluster object to check
.EXAMPLE
  PS> Get-MissingPortGroups -Cluster (Get-Cluster CL01)
.EXAMPLE
  PS> Get-Cluster | Get-MissingPortGroups
#>

  param(
   [parameter(valuefrompipeline = $true, mandatory = $true,
     HelpMessage = "Enter a cluster entity")]
   [VMware.VimAutomation.ViCore.Impl.V1.Inventory.ClusterImpl]$cluster)

  process{
#create an array with all available portgroups in the cluster
    $clusterHosts = @($cluster | Get-VMHost)
    $refPortGroups = @($clusterHosts | Get-VirtualPortGroup | Select-Object -Unique)
  
#compare the hosts against the reference array
    foreach ($vmHost in $clusterHosts) {
      $difPortGroups = @($vmHost | Get-VirtualPortGroup)
      $differences = @(Compare-Object $refPortGroups $difPortGroups)
      foreach ($item in $differences) {
        $objPG = "" | Select Cluster,HostName,MissingPortGroup
        $objPG.Cluster = $cluster
        $objPG.HostName = $vmHost.Name
        $objPG.MissingPortGroup = $item.InputObject
        $objPG
      }
    }
  }
}

function Export-Xls{
  <#
.SYNOPSIS
  Saves Microsoft .NET Framework objects to a worksheet in an
  XLS file
.DESCRIPTION
  The Export-Xls function allows you to save Microsoft .NET
  Framework objects to a named worksheet in an Excel file
  (type XLS). The position of the worksheet can be specified.
.NOTES
  Source:  Automating vSphere Administration
  Authors: Luc Dekens, Arnim van Lieshout, Jonathan Medd,
           Alan Renouf, Glenn Sizemore
.PARAMETER InputObject
  Specifies the objects to be written to the worksheet.
  The parameter accepts objects through the pipeline.
.PARAMETER Path
  Specifies the path to the XLS file.
.PARAMETER WorksheetName
  The name for the new worksheet. If not specified the name will
  be "Sheet" followed by the "Ticks" value.
.PARAMETER SheetPosition
  Specifies where the new worksheet will be inserted in the
  series of existing worksheets. You can specify "begin" or
  "end". The default is "begin".
.PARAMETER ChartType
  Specifies the type of chart you want to add to the worksheet.
  All types in the [microsoft.Office.Interop.Excel.XlChartType]
  enumeration are accepted.
.PARAMETER NoTypeInformation
  Omits the type information from the worksheet. The default is
  to include the "#TYPE" line.
.PARAMETER AppendWorksheet
  Specifies if the worksheet should keep or remove the existing
  worksheet in the spreadsheet. The default is to append.
.EXAMPLE
  PS> $data = Get-Process | Select-Object Name, Id, WS
  PS> Export-Xls $data C:\Reports\MyWkb.xls -WorksheetName "WS" -AppendWorksheet:$false
.EXAMPLE
  PS> $data = Get-Process | Select-Object Name, Id, WS
  PS> Export-Xls $data C:\Reports\MyWkb.xls -SheetPosition "end"
.EXAMPLE
  PS> $data = Get-Process | Select-Object Name, Id, WS
  PS> Export-Xls $data C:\Reports\MyWkb.xls -WorksheetName "WS" -ChartType "xlColumnClustered"
#>
  param(
  [parameter(ValueFromPipeline = $true,Position=1)]
  [ValidateNotNullOrEmpty()]
    $InputObject,
  [parameter(Position=2)]
  [ValidateNotNullOrEmpty()]
    [string]$Path,
    [string]$WorksheetName = ("Sheet " + (Get-Date).Ticks),
    [string]$SheetPosition = "begin",
    [PSObject]$ChartType,
    [switch]$NoTypeInformation = $true,
    [switch]$AppendWorksheet = $true
  )

  begin{
    [System.Reflection.Assembly]::LoadWithPartialName("Microsoft.Office.Interop.Excel")
    if($ChartType){
      [microsoft.Office.Interop.Excel.XlChartType]$ChartType = $ChartType
    }
    
    function Set-ClipBoard{
      param(
        [string]$text
      )
      process{
        Add-Type -AssemblyName System.Windows.Forms
        $tb = New-Object System.Windows.Forms.TextBox
        $tb.Multiline = $true
        $tb.Text = $text
        $tb.SelectAll()
        $tb.Copy()
      }
    }

    function Add-Array2Clipboard {
      param (
        [PSObject[]]$ConvertObject,
        [switch]$Header
      )
      process{
        $array = @()
        
        if ($Header) {
          $line =""
          $ConvertObject | Get-Member -MemberType Property,NoteProperty,CodeProperty | Select -Property Name | %{
            $line += ($_.Name.tostring() + "`t")
          }
          $array += ($line.TrimEnd("`t") + "`r")
        }
        else {
          foreach($row in $ConvertObject){
            $line =""
            $row | Get-Member -MemberType Property,NoteProperty | %{
              $Name = $_.Name
              if(!$Row.$Name){$Row.$Name = ""}
              $line += ([string]$Row.$Name + "`t")
            }
            $array += ($line.TrimEnd("`t") + "`r")
          }
        }
        Set-ClipBoard $array
      }
    }

    $excelApp = New-Object -ComObject "Excel.Application"
    $originalAlerts = $excelApp.DisplayAlerts
    $excelApp.DisplayAlerts = $false
    if(Test-Path -Path $Path -PathType "Leaf"){
      $workBook = $excelApp.Workbooks.Open($Path)
    }
    else{
      $workBook = $excelApp.Workbooks.Add()
    }
    $sheet = $excelApp.Worksheets.Add($workBook.Worksheets.Item(1))
    if(!$AppendWorksheet){
      $workBook.Sheets | where {$_ -ne $sheet} | %{$_.Delete()}
    }
    $sheet.Name = $WorksheetName
    if($SheetPosition -eq "end"){
      $nrSheets = $workBook.Sheets.Count
      2..($nrSheets) |%{
        $workbook.Sheets.Item($_).Move($workbook.Sheets.Item($_ - 1))
      }
    }
    $sheet.Activate()
    $array = @()
  }

  process{
    $array += $InputObject
  }

  end{
    Add-Array2Clipboard $array -Header:$True
    $selection = $sheet.Range("A1")
    $selection.Select() | Out-Null
    $sheet.Paste()
    $Sheet.UsedRange.HorizontalAlignment = [microsoft.Office.Interop.Excel.XlHAlign]::xlHAlignCenter
    Add-Array2Clipboard $array
    $selection = $sheet.Range("A2")
    $selection.Select() | Out-Null
    $sheet.Paste() | Out-Null
    $selection = $sheet.Range("A1")
    $selection.Select() | Out-Null

    $sheet.UsedRange.EntireColumn.AutoFit() | Out-Null
    $workbook.Sheets.Item(1).Select()
    if($ChartType){
      $sheet.Shapes.AddChart($ChartType) | Out-Null
    }
    $workbook.SaveAs($Path)
    $excelApp.DisplayAlerts = $originalAlerts
    $excelApp.Quit()
    Stop-Process -Name "Excel"
  }
}
function Get-AggregationJobs{
<#
.SYNOPSIS
  Returns the SQL jobs that perform vCenter statistical data aggregation
.DESCRIPTION
  The function takes all SQL jobs in the "Stats Rollup" category
  and returns key data for each of the jobs
.NOTES
  Source:  Automating vSphere Administration
  Authors: Luc Dekens, Arnim van Lieshout, Jonathan Medd,
           Alan Renouf, Glenn Sizemore
.PARAMETER SqlServer
  Name of the SQL server where the vSphere database is hosted 
.EXAMPLE
  PS> Get-AggregationJobs "serverA"
#>

  param(
    [parameter(mandatory = $true,
      HelpMessage = "Enter the name of the vCenter SQL server")]
    [string]$SqlServer)
  
  [System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SMO') | `
    out-null
  $sqlSRv = new-object ('Microsoft.SqlServer.Management.Smo.Server') $sqlServer 

  $sqlSrv.JobServer.Jobs | `
    where {$_.Category -eq "Stats Rollup"} | %{
    New-Object PSObject -Property @{
      Name = $_.Name
      Description = $_.Description
      LastRun = $_.LastRunDate
      NextRun = $_.NextRunDate
      LastRunResult = $_.LastRunOutcome
      "Schedule(s)" = $_.JobSchedules | %{$_.Name}
    }
  }
}

function Set-StatIntervalLevel{
  <#
.SYNOPSIS
  Change the statistics level of a Historical Interval
.DESCRIPTION
  The function changes the statistics level, specified in $Name,
  to a new level, specified in $Level.
  The new statistics level can not be higher than the statistics
  level of the previous Historical Interval
.NOTES
  Source:  Automating vSphere Administration
  Authors: Luc Dekens, Arnim van Lieshout, Jonathan Medd,
           Alan Renouf, Glenn Sizemore
.PARAMETER Interval
  The Historical Interval for which you want to change the level
.PARAMETER Level
  New statistics level
.EXAMPLE
  PS> Set-StatIntervalLevel -Interval (Get-StatInterval -Name "Past week") -Level 3
.EXAMPLE
  PS> Get-StatInterval -Name "Past day" | Set-StatIntervalLevel -Level 4
#>

  param(
  [parameter(valuefrompipeline = $true, mandatory = $true,
  HelpMessage = "Enter the name of the interval")]
  [VMware.VimAutomation.Types.StatInterval]$Interval,
  [parameter(mandatory = $true,
  HelpMessage = "Enter the new level of the Historical Interval")]
  [string]$Level)

  begin{
    $perfMgr = Get-View (Get-View ServiceInstance).content.perfManager
  }

  process{
    $intervalSDK = $perfMgr.historicalInterval | where {$_.Name -eq $Interval.Name}
    $intervalSDK.Level = $level
    $perfMgr.UpdatePerfInterval($intervalSDK)
  }

  end{}
}

function Get-StatTypeDetail{
  <#
.SYNOPSIS
  Returns available metrics for an entity
.DESCRIPTION
  The function returns the available metrics for a specific entity.
  Entities can be ESX(i) host, clusters, resource pools or virtual
  machines.
  The function can return the available metrics for all the
  historical intervals together or for the realtime interval
.NOTES
  Source:  Automating vSphere Administration
  Authors: Luc Dekens, Arnim van Lieshout, Jonathan Medd,
           Alan Renouf, Glenn Sizemore
.PARAMETER Entity
  The entity for which the metrics should be returned
.PARAMETER Realtime
  Switch to select the realtime metrics
.EXAMPLE
  PS> Get-StatTypeDetail -Entity (Get-VM "Guest1")
.EXAMPLE
  PS> Get-StatTypeDetail -Entity (Get-VMHost "esx41") -Realtime
.EXAMPLE
  PS> Get-VM "Guest1" | Get-StatTypeDetail
#>

  param(
  [parameter(valuefrompipeline = $true, mandatory = $true,
  HelpMessage = "Enter an entity")]
  [VMware.VimAutomation.Types.VIObject[]]$Entity,
  [switch]$Realtime)
  begin{
# Create performance counter hashtables
    $perfMgr = Get-View (Get-View ServiceInstance).content.perfManager
    $pcTable = New-Object Hashtable
    $keyTable = New-Object Hashtable
    foreach($pC in $perfMgr.PerfCounter){
      if($pC.Level -ne 99){
        $pCKey = $pC.GroupInfo.Key + "." + $pC.NameInfo.Key + "." + $pC.RollupType
        $pCKey = $pCKey.ToLower()
        if(!$pctable.ContainsKey($pCKey)){
          $pctable.Add($pcKey,$pC.Key)
        }
      }
    }
  }
  
  process{
    if($Entity){
      $entSDK = $entity | Get-View
    }
    else{
      $entSDK = $_ | Get-View
    }

# Get the metrics
    $entSDK | %{
      $metrics = $perfMgr.QueryAvailablePerfMetric($entSDK.MoRef,
                                                   $null,
                                                   $null,
                                                   $numinterval)
      $metricsNoInstances = $metrics | where {$_.Instance -eq ""}
      $metricslist = @()
      foreach($pmId in $metricsNoInstances){
        $row = "" | select Group, Name, Rollup, Id, Level, Type, Unit
        $pC = $keyTable[$pmId.CounterId]
        $row.Group = $pC.GroupInfo.Key
        $row.Name = $pC.NameInfo.Key
        $row.Rollup = $pC.RollupType
        $row.Id = $pC.Key
        $row.Level = $pC.Level
        $row.Type = $pC.StatsType
        $row.Unit = $pC.UnitInfo.Key
        $metricslist += $row
      }
    }
  }
  end{
    $metricslist | Sort-Object -Property Group,Name,Rollup
  }
}

function Get-StatInstances{
  <#
.SYNOPSIS
  Returns the available instances for a specific metric and entity
.DESCRIPTION
  The function returns all the available instances for a metric on an
  entity. The entity can be one an ESX(i) host, a cluster, a resource pool 
  or a virtual machine.
.NOTES
  Source:  Automating vSphere Administration
  Authors: Luc Dekens, Arnim van Lieshout, Jonathan Medd,
           Alan Renouf, Glenn Sizemore
.PARAMETER Entity
  The entity or entities for which the instances should be returned
.PARAMETER Stat
  The metric or metrics for which the instances should be returned
.PARAMETER Realtime
  Switch to select the realtime metrics
.EXAMPLE
  PS> Get-StatInstances -Entity (Get-VM "Guest1") -Stat "cpu.usage.average"
.EXAMPLE
  PS> Get-StatInstances -Entity $esx -Stat "cpu.usage.average" -Realtime
.EXAMPLE
  PS> Get-VMHost MyEsx | Get-StatInstances -Stat "disk.devicelatency.average"
#>

  param(
  [parameter(valuefrompipeline = $true, mandatory = $true,
  HelpMessage = "Enter an entity")]
  [PSObject[]]$Entity,
  [parameter(mandatory=$true,
  HelpMessage = "Enter a metric")]
  [string[]]$Stat,
  [switch]$Realtime)

  begin{
# Create performance counter hashtables
    $perfMgr = Get-View (Get-View ServiceInstance).content.perfManager
    $pcTable = New-Object Hashtable
    foreach($pC in $perfMgr.PerfCounter){
      if($pC.Level -ne 99){
        $pCKey = ($pC.GroupInfo.Key + "." + $pC.NameInfo.Key + "." + `
                                      $pC.RollupType)
        $pCKey = $pCKey.ToLower()
        if(!$pctable.ContainsKey($pCKey)){
          $pctable.Add($pcKey,$pC.Key)
        }
      }
    }
  }

  process{
    if($Entity){
      $entSDK = $entity | Get-View
    }
    else{
      $entSDK = $_ | Get-View
    }

# Handle the Realtime switch
    $numinterval = $null
    if($Realtime){
      $provSum = $perfMgr.QueryPerfProviderSummary($entSDK.MoRef)
      $numinterval = $provSum.refreshRate
    }

# Get the metrics for the entity
    $entSDK | %{
      $metrics += $perfMgr.QueryAvailablePerfMetric($_.MoRef,
                                                    $null,
                                                    $null,
                                                    $numinterval)

# Check is stat is valid
      foreach($st in $stat){
        if(!$pcTable.ContainsKey($st.ToLower())){
          Throw "-Stat parameter $st is invalid."
        }
        else{
          $ids += $pcTable[$st]
        }
        foreach($metric in $metrics){
          if($metric.CounterId -eq $pcTable[$st.ToLower()]){
            New-Object PSObject -Property @{
              StatName = $st
              Instance = $metric.Instance
            }
          }
        }
      }
    }
  }
}

function Get-StatReference{
  <#
.SYNOPSIS
  Creates a HTML reference of all the available metrics
.DESCRIPTION
  The function returns a simple HTML page which contains all the
  available metrics in the environment where you are connected.
.NOTES
  Source:  Automating vSphere Administration
  Authors: Luc Dekens, Arnim van Lieshout, Jonathan Medd,
           Alan Renouf, Glenn Sizemore
.EXAMPLE
  PS> Get-StatReference | Out-File "$env:temp\metricRef.html"
#>

  begin{
# In API 4.0 there is a bug.
# There are 4 duplicate metrics that only differ in the case
# These are excluded with the -notcontains condition
    $badMetrics = "mem.reservedcapacity.average",
      "cpu.reservedcapacity.average",
      "managementAgent.swapin.average",
      "managementAgent.swapout.average"
    $perfMgr = Get-View (Get-View ServiceInstance).content.perfManager
  }
  
  process{
# Create performance counter hashtables
    $metricRef = foreach($pC in $perfMgr.PerfCounter){
      if($pC.Level -ne 99){
        $pCKey = ($pC.GroupInfo.Key + "." + $pC.NameInfo.Key + "." + `
                                     $pC.RollupType)
        if($badMetrics -notcontains $pCKey){
          $pCKey = $pCKey.ToLower()
          New-Object PSObject -Property @{
            Metric = $PCKey
            Level = $pC.Level
            Unit = $pC.UnitInfo.Label
            Description = $pC.NameInfo.Summary
          }
        }
      }
    }
  }
  
  end{
    $metricRef | Sort-Object -Property Metric | `
      ConvertTo-Html -Property Metric,Level,Unit,Description
  }
}

function Get-vCenterScheduledTask{
    <#
    .SYNOPSIS
        Retrieve vCenter Scheduled Tasks.
    .DESCRIPTION
        Retrieve vCenter Scheduled Tasks.
    .NOTES
        Source:  Automating vSphere Administration
        Authors: Luc Dekens, Arnim van Lieshout, Jonathan Medd,
                 Alan Renouf, Glenn Sizemore
	.EXAMPLE
        Get-vCenterScheduledTask | Select-Object Name,Description,NextRunTime,PrevRunTime,State,Notification
    #> 
 
    $si = Get-View ServiceInstance
    $scheduledTaskManager = Get-View $si.Content.ScheduledTaskManager
    $tasks = $scheduledTaskManager.RetrieveEntityScheduledTask($null)
    $scheduledtasks = foreach ($task in $tasks){(Get-View $task).info}
    $scheduledtasks

}
