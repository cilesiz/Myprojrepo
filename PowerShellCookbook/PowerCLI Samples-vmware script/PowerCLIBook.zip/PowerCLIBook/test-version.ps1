# Verify PowerCLI is installed and loaded.
# should probably use a # requires, but... 
Try
{
    IF ((Get-PSSnapin -Name VMware.VimAutomation.Core -ea stop).version -lt [System.Version]"4.0")
    {
        
        throw "Module Requires PowerCLI 4.1 or newer"
        
    }
}
Catch
{
    Add-PSSnapin -Name VMware.VimAutomation.Core -ea stop
    if (!$?)
    {
        throw "Module Requires PowerCLI 4.1 or newer"
    }
}
Finally
{
    write-host "Thank you for purchasing Automating vSphere Administration" -ForegroundColor Green
}