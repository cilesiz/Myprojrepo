﻿

function Get-HostPartitionDiskspace
{
    <#
    .SYNOPSIS
        Retrieve ESX Host Partition Disk Space.
    .DESCRIPTION
        Use Plink.exe to retrieve ESX Host Partition Disk Space.
    .NOTES
          Authors:  Luc Dekens & Jonathan Medd
    .PARAMETER User
        Host User Credential
    .PARAMETER Password
        Host Password Credential
    .PARAMETER HostName
        Name of Host to connect to
    .PARAMETER Plink
       Path to plink.exe. Default is C:\Putty\plink.exe
    .EXAMPLE
        Get-HostPartitionDiskspace -User Admin -Password -Test -HostName Server01
    #>
    [CmdletBinding()]
    Param(
         [parameter(Mandatory=$True
        ,    HelpMessage='Host User Credential'
        )]
        [String]
        $User
    ,    
         [parameter(Mandatory=$True
        ,    HelpMessage='Host Password Credential'
        )]
        [String]
        $Password
        
    ,    
         [parameter(Mandatory=$True
        ,    HelpMessage='Name of Host to connect to'
        )]
        [String]
        $HostName
        
    ,    
         [parameter(
            HelpMessage='Path to plink.exe'
        )]
        [String]
        $plink = "C:\Putty\plink.exe"
    )
    if (-not(Test-Path $plink)) {
        Write-Host -ForegroundColor Red "Please re-run and supply the correct path to plink.exe"
        Break    
    }

    $plinkoptions = " -v -batch -pw $Password"
    $cmd1 = 'df'

    $remoteCommand = '"' + $cmd1 + '"'
    $command = $plink + " " + $plinkoptions + " " + $User + "@" + $HostName + " " + $remoteCommand

    Invoke-Expression -command $command
}
