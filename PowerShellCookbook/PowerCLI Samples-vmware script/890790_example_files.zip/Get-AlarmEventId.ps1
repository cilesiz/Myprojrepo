function Get-AlarmEventId{
  <#
.SYNOPSIS
  Returns the data needed to define an EventAlarmExpression
.DESCRIPTION
  The function will return the required properties that
  are needed to populate the eventType and eventTypeId
  properties
.NOTES
    Source:  Automating vSphere Administration
    Authors: Luc Dekens, Arnim van Lieshout, Jonathan Medd,
             Alan Renouf, Glenn Sizemore
.EXAMPLE
  PS> Get-AlarmEventId | Export-Csv "C:\Alarm-eventId.csv"
#>

  begin{
    $commonArgs = "changeTag","computeResource","computeResource.name",
                  "datacenter","datacenter.name","ds","ds.name","dvs",
                  "dvs.name","fullFormattedMessage","host","host.name",
                  "net","net.name","userName","vm","vm.name"
  }
  
  process{
    $evtMgr = Get-View EventManager

    $evtMgr.Description.EventInfo |%{
      $row = "" | Select EventType,EventTypeId,Group,Description,Attributes
      $row.Description = $_.Description
      if($_.Key -eq "eventEx"){
        $eventTypeName = $_.FullFormat.Split("|")[0]
        $row.EventType = "EventEx|ExtendedEvent"
        $row.EventTypeId = $_.FullFormat.Split("|")[0]
        $attributes = $evtMgr.RetrieveArgumentDescription($row.EventTypeId)
        if($attributes){
          $specialAttributes = $attributes | `
            where{$commonArgs -notcontains $_.Name} | `
            %{$_.Name + "(" + $_.Type + ")"}
          if($specialAttributes.Count){
            $row.Attributes = [string]::Join(',',$specialAttributes)
          }
          elseif($specialAttributes){
            $row.Attributes = $specialAttributes
          }
        }
        $row.Group = "EventEx"
      }
      elseif($_.Key -eq "ExtendedEvent"){
        $row.EventType = "ExtendedEvent|EventEx"
        $row.EventTypeId = $_.FullFormat.Split("|")[0]
        $attributes = $evtMgr.RetrieveArgumentDescription($row.EventTypeId)
        if($attributes){
          $specialAttributes = $attributes | `
            where{$commonArgs -notcontains $_.Name} | `
            %{$_.Name + "(" + $_.Type + ")"}
          if($specialAttributes.Count){
            $row.Attributes = [string]::Join(',',$specialAttributes)
          }
          elseif($specialAttributes){
            $row.Attributes = $specialAttributes
          }
        }
        $row.Group = "ExtendedEvent"
      }
      else{
        $eventTypeName = $_.Key
        $row.EventType = $eventTypeName
        $row.EventTypeId = "vim.event." + $_.Key
        $attributes = $evtMgr.RetrieveArgumentDescription($row.EventTypeId)
        if($attributes){
          $specialAttributes = $attributes | `
            where{$commonArgs -notcontains $_.Name} | `
            %{$_.Name + "(" + $_.Type + ")"}
          if($specialAttributes.Count){
            $row.Attributes = [string]::Join(',',$specialAttributes)
          }
          elseif($specialAttributes){
            $row.Attributes = $specialAttributes
          }
        }
        $row.Group = "regular"
      }
      $row
    }
  }
}
