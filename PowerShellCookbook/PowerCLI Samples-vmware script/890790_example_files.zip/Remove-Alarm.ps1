function Remove-Alarm{
  <#
.SYNOPSIS
  Removes one or more alarms
.DESCRIPTION
  The function will remove all the alarms whose
  name matches.
.NOTES
    Source:  Automating vSphere Administration
    Authors: Luc Dekens, Arnim van Lieshout, Jonathan Medd,
             Alan Renouf, Glenn Sizemore
.EXAMPLE
  PS> Remove-Alarm -Name "Book: My Alarm"
.EXAMPLE
  PS> Remove-Alarm -Name "Book:*"
#>

  param(
  [string]$Name
  )
  
  process{
    $alarmMgr = Get-View AlarmManager
    $alarmMgr.GetAlarm($null) | %{
      $alarm = Get-View $_
      if($alarm.Info.Name -like $Name){
        $alarm.RemoveAlarm()
      }
    }
  }
}
