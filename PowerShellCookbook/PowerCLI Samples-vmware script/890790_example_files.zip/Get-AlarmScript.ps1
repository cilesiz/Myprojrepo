function Get-AlarmScript{
<#
.SYNOPSIS
  Convert an Alarm into a PowerShell script
.DESCRIPTION
  The function produces a PowerShell script that
  contains all the parameters present in an alarm.
.NOTES
  Source:  Automating vSphere Administration
  Authors: Luc Dekens, Arnim van Lieshout, Jonathan Medd,
           Alan Renouf, Glenn Sizemore
.EXAMPLE
  PS> Get-Alarm -Name �My Alarm� | Get-AlarmScript | Set-Content �C:\myAlarm.ps1�
#>

  param(
  [PSObject]$Alarm
  )

  begin{
    $perfMgr = Get-View (Get-View ServiceInstance).Content.PerfManager
    $perfTab = @{}
    $perfMgr.PerfCounter | %{
      $perfKey = $_.GroupInfo.Key + '.' + $_.NameInfo.Key + '.' + $_.RollupType
      $perfTab[$perfKey] = $_.Key
    }
  }
  
  process{
    $text = @()

    $text += '#requires -version 2'
    $text += '#requires -pssnapin VMware.VimAutomation.Core -version 4.1'
    $text += ''
    $text += '$spec = New-Object VMware.Vim.AlarmSpec'
    $text += '$spec.Name = "' + $Alarm.Name + '"'
    $text += '$spec.Description = "' + $Alarm.Description + '"'
    $text += '$spec.ActionFrequency = ' + [int]$Alarm.ActionFrequency
    $text += '$spec.Enabled = $' + $Alarm.Enabled
    $text += ''
    if($Alarm.Action){
      $text += '$action = New-Object VMware.Vim.' + $Alarm.Action.Type
      $text += ''
      $i = 1
      foreach($action in $Alarm.Action.Action){
        $text += '$action' + $i + ' = New-Object VMware.Vim.' + $action.Type
        $text += '$action' + $i + '.Green2yellow = $' + $action.Green2yellow
        $text += '$action' + $i + '.Red2yellow = $' + $action.Red2yellow
        $text += '$action' + $i + '.Yellow2green = $' + $action.Yellow2green
        $text += '$action' + $i + '.Yellow2red = $' + $action.Yellow2red

        switch($action.Action.Type){
          "SendEmailAction" {
            $text += '$action' + $i + `
              '.Action = New-Object VMware.Vim.SendEmailAction'
            $text += '$action' + $i + `
              '.Action.Body = "' + $action.Action.Body + '"'
            $text += '$action' + $i + `
              '.Action.CcList = "' + $action.Action.CcList + '"'
            $text += '$action' + $i + `
              '.Action.Subject = "' + $action.Action.Subject + '"'
            $text += '$action' + $i + `
              '.Action.ToList = "' + $action.Action.ToList + '"'
            $text += ''
          }
          "SendSNMPAction" {
            $text += '$action' + $i + `
              '.Action = New-Object VMware.Vim.SendSNMPAction'
            $text += ''
          }
        }

        $j = 1
        foreach($trans in $action.TransitionSpec){
          $text += '$trans' + $j + `
            ' = New-Object VMware.Vim.AlarmTriggeringActionTransitionSpec'
          $text += '$trans' + $j + '.StartState = "' + $trans.StartState + '"'
          $text += '$trans' + $j + '.FinalState = "' + $trans.FinalState + '"'
          $text += '$trans' + $j + '.Repeats = $' + $trans.Repeats
          $text += ''
          $text += '$action' + $i + '.TransitionSpecs += $trans' + $j
          $text += ''
          $j++
        }
        $text += '$action.' + 'Action += $action' + $i
        $text += ''
        $i++
      }
      $text += ''
      $text += '$spec.Action = $action'
      $text += ''
    }

    if($Alarm.Expression){
      $text += '$expression = New-Object VMware.Vim.' + `
        $Alarm.Expression.Type
      $text += ''
      if($Alarm.Expression.Expression){
        $i = 1
        foreach($expression in $Alarm.Expression.Expression){
          switch($expression.ExpressionType){
            "EventAlarmExpression" {
              $text += '$expression' + $i + `
                ' = New-Object VMware.Vim.' + $expression.ExpressionType
              if($expression.Comparisons){
                $j = 1
                $expression.Comparisons | %{
                  $text += ''
                  $text += '$comparison' + $j + `
                    ' = VMware.Vim.EventAlarmExpressionComparison'
                  $text += '$comparison' + $j + `
                    '.attributeName = ' + $_.AttributeName
                  $text += '$comparison' + $j + '.operator = ' + $_.Operator
                  $text += '$comparison' + $j + '.value = ' + $_.value
                  $text += '$expression.Comparisons += $comparison' + $j
                }
              }
              $text += '$expression' + $i + `
                '.EventType = ' + $expression.EventType
              $text += '$expression' + $i + `
                '.EventTypeId = ' + $expression.EventTypeId
              $text += '$expression' + $i + `
                '.ObjectType = ' + $expression.ObjectType
              $text += '$expression' + $i + '.status = ' + $expression.Status
              $text += '' 
            }
            "MetricAlarmExpression" {
              $text += '$expression' + $i + `
                ' = New-Object VMware.Vim.' + $expression.ExpressionType
              $text += '$expression' + $i + `
                '.metric = New-Object VMware.Vim.PerfMetricId'
              $text += '$expression' + $i + `
                '.metric.counterId = ' + $perfTab[$expression.Metric.Counter]
              $text += '$expression' + $i + `
                '.metric.instance = "' + $expression.Metric.Instance + '"'
              $text += '$expression' + $i + `
                '.operator = "' + $expression.Operator + '"'
              $text += '$expression' + $i + '.red = ' + $expression.Red
              $text += '$expression' + $i + `
                '.redInterval = ' + $expression.redInterval
              $text += '$expression' + $i + '.type = "' + $expression.Type + '"'
              $text += '$expression' + $i + '.yellow = ' + $expression.Yellow
              $text += '$expression' + $i + `
                '.yellowInterval = ' + $expression.yellowInterval
              $text += '' 
            }
            "StateAlarmExpression" {
              $text += '$expression' + $i + `
                ' = New-Object VMware.Vim.' + $expression.ExpressionType
              $text += '$expression' + $i + `
                '.operator = "' + $expression.Operator + '"'
              $text += '$expression' + $i + '.red = ' + $expression.Red
              $text += '$expression' + $i + `
                '.statePath = ' + $expression.StatePath
              $text += '$expression' + $i + '.type = "' + $expression.Type +'"'
              $text += '$expression' + $i + '.yellow = ' + $expression.Yellow
              $text += '' 
            }
          }
          $text += '$expression.Expression += $expression' + $i
          $text += ''
          $i++
        }
      }
      $text += '$spec.Expression = $expression'
      $text += ''
    }

    if($Alarm.Setting){
      $text += '$setting = New-Object VMware.Vim.AlarmSetting'
      $text += '$setting.reportingFrequency = ' + `
        $Alarm.Setting.ReportingFrequency
      $text += '$setting.toleranceRange = `
        ' + $Alarm.Setting.ToleranceRange
      $text += ''
      $text += '$spec.Setting = $setting'
      $text += ''
    }

    $text += '$entity = Get-Inventory -Name ' + $Alarm.Entity.Name
    $text += ''
    $text += '$alarmMgr = Get-View AlarmManager'
    $text += '$alarmMgr.CreateAlarm($entity.Extensiondata.MoRef,$spec)'

    $text
  }
}
