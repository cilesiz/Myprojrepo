$a = 2
$b = 5
$d = $a + $b
'The value of $c is: ' + $c