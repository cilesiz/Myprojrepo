function Get-PowerShellCommand
{

    param()
    
    
    process {
        [ShowUI.ShowUICommands]::BackgroundPowerShellCommand
    }
}
