﻿function Get-CurrentScriptPath
{
	param()
	
	process {
		Get-CurrentDocument -Path		
	}
}