﻿function Get-CurrentDocumentEditor
{
	param()
	
	process {
        Get-CurrentDocument -Editor			
	}
}