﻿{
	Start-SparkPlug
} | 
	Add-Member NoteProperty ShortcutKey "CONTROL+ALT+S" -PassThru