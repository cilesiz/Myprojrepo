﻿@{
    Command = (Get-Command Add-CommentHelp)
    ShortcutKey = "CTRL + ALT + H"
}