﻿@{
    Command = (Get-Command Add-Parameter)
    ShortcutKey = "Alt + P"
}